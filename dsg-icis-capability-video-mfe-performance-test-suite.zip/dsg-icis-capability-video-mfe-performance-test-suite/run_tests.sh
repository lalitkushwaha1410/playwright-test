#!/bin/bash
# Install dependencies and execute tests
yarn add puppeteer-core && \
yarn add -g lighthouse && \
yarn add --dev @lhci/cli@0.12.0 && \

CLASSNAME=${CLASSNAME:-$1}

if [ "$CLASSNAME" == "chromeTest" ]; then
  yarn chromeTest
else
  echo "Unknown CLASSNAME: $CLASSNAME"
  exit 1
fi