import { shared } from '../fixtures/constants/shared';
import { VideoPage } from '../support/ui/pages/Video.po';
import "cypress-audit/commands";
var user="";

describe('Performance Test for Video',{ testIsolation: false }, () => {
  const videoPage= new VideoPage();
  beforeEach(() => {
    cy.viewport(1280, 720);
  });

  before(() => {
    cy.clearAllSessionStorage();
    cy.clearAllCookies();

  });

  it('should run performance test for Authoring', { taskTimeout: 90_000 },() => {
    
    const customThresholds = {
      performance: 10,
      accessibility: 10,
      'first-contentful-paint': 8000,
      'largest-contentful-paint': 20000,
      'cumulative-layout-shift': 0.1,
      'total-blocking-time': 8000,
      interactive: 25000,
      seo: 60,
    };
  
    const desktopConfig = {
      formFactor: "desktop",
      screenEmulation: {
        width: 1350,
        height: 940,
        deviceScaleRatio: 1,
        mobile: false,
        disable: false,
      },
      throttling: {
        rttMs: 40,
        throughputKbps: 11024,
        cpuSlowdownMultiplier: 1,
        requestLatencyMs: 0,
        downloadThroughputKbps: 0,
        uploadThroughputKbps: 0,
      },
    }; 

    cy.appUrl();
    cy.Login(shared.users.authoringUser.username, Cypress.env('password'));
    videoPage.clickOnAddVideo();
    videoPage.enterVideoURL(shared.videoURL);
    videoPage.clickOnPopupNextButtonfortestharness();
    videoPage.clickOnPopupAddToPageButtonfortestharness();
    user = "Author";

    Cypress.env('user',user);
    cy.url().should('contain', 'version');
  
    cy.location('search').then((search) => {
      const idMatch = search.match(/id=([^&]*)/);
      const versionMatch = search.match(/version=([^&]*)/);
    
      const id = idMatch ? idMatch[1] : null;
      const version = versionMatch ? versionMatch[1] : null;
      Cypress.env('id', id);
      Cypress.env('version', version);
      cy.log(id);
      cy.log(version);
    });

    cy.task('setLighthouseReportName', user)
      .then(() => {
        cy.lighthouse(customThresholds, desktopConfig);
      })
  });

  it('should run performance test for Subscriber' , { taskTimeout: 90_000 },() => {
    
    const customThresholds = {
      performance: 10,
      accessibility: 10,
      'first-contentful-paint': 8000,
      'largest-contentful-paint': 20000,
      'cumulative-layout-shift': 0.1,
      'total-blocking-time': 8000,
      interactive: 25000,
      seo: 60,
    };
  
    const desktopConfig = {
      formFactor: "desktop",
      screenEmulation: {
        width: 1350,
        height: 940,
        deviceScaleRatio: 1,
        mobile: false,
        disable: false,
      },
      throttling: {
        rttMs: 40,
        throughputKbps: 11024,
        cpuSlowdownMultiplier: 1,
        requestLatencyMs: 0,
        downloadThroughputKbps: 0,
        uploadThroughputKbps: 0,
      },
    }; 

    const id = Cypress.env('id');
    const version = Cypress.env('version');
    const env = Cypress.env('ENV');
    cy.visit(shared.enviroment.subscriber[env] + id +"&version=" + version);
    videoPage.LoginIntoSubscriberView();
    videoPage.findVideoInSubscriber();

    cy.url().should('contain', 'version');
    user = "Subscriber";

   cy.task('setLighthouseReportName', user)  
      .then(() => {
        cy.lighthouse(customThresholds, desktopConfig);
    })

  });
  

});
