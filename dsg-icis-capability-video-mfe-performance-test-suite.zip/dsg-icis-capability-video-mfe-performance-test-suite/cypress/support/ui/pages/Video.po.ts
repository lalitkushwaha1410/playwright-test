/// <reference types="cypress" />

import { shared } from '../../../fixtures/constants/shared';

export class VideoPage {
  clickAddVideo = 'div[data-testid^="video_capability"]>div:nth-of-type(1)>button';
  subscriberUsername ='input[id="username-input"]';
  subscriberPassword = 'input[id="password-input"]';
  subcriberLoginButton ='button[id="login-button"]';
 
public clickOnAddVideo(){
  cy.get(this.clickAddVideo).should('contain', "Add video");
  cy.get('div').contains('Add video').click();
  cy.wait(6000);
}

public  enterVideoURL(url: string){
  //cy.get('input[data-testid="url__input__box"][id="inputUrl"]').type(url).wait(5000);
//  cy.get('input[data-testid="url__input__box"][id="inputUrl"]').type(url,{delay:500}).wait(10000);
  cy.get('input[data-testid="url__input__box"][id="inputUrl"]', { timeout: 14000 }).should('be.visible').clear().type(shared.videoURL);
}
 
public clickOnPopupNextButtonfortestharness(){
 // cy.waitForEnabled('button:contains("Next")', 12000);
  cy.contains('Next',{ timeout: 12000 }).should('be.enabled');
  cy.contains('Next').click();
 // cy.get(this.TH_popupNextButton).click();
  cy.wait(6000);
}

public clickOnPopupAddToPageButtonfortestharness(){
  cy.contains('Add to page').should('be.enabled');
  cy.contains('Add to page').click();
  //cy.get(this.TH_popupAddToPageButton).click();
  cy.wait(6000);
}

public LoginIntoSubscriberView(){
  cy.get(this.subscriberUsername,{ timeout: 5000 }).should('exist');
  cy.get(this.subscriberUsername).type(shared.users.subscriberUser.username);
  cy.get(this.subscriberPassword).type("Passw0rd");
  cy.get(this.subcriberLoginButton).click();
  cy.wait(15000);
}

public findVideoInSubscriber(){
  cy.get('div[data-testid="video__view__container"]').should('be.visible');
  cy.wait(5000);
}
}
