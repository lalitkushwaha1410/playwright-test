export const shared = {
  users: {
    authoringUser: {
      //// User for login into authoring app
      username: 'cha\\SptCmsTestEditor@cha.rbxd.ds',
    },
    subscriberUser: {
      //// User for login into subscriber app
      username: 'chubtestuser@icis.com',
    }
  },
  enviroment: {
    subscriber: {
      systest:'https://subscriber.systest.genesis.cha.rbxd.ds/mfe/video?id=',
      staging: 'https://subscriber.staging.genesis.cha.rbxd.ds/mfe/video?id=',
    }
  },
  videoURL : 'https://video.icis.com/watch/5u23nD47GEGFAEMdMbQfrQ',
};
