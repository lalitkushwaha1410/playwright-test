const path = require("path");
const { CleanWebpackPlugin } = require("clean-webpack-plugin");

module.exports = {
  mode: "production",
  context: path.join(__dirname, "src"),
  entry: {
    saveImageApi: "./saveImageApi.ts",
    getImageApi: "./getImageApi.ts",
    subscriber_getImageApi: "./subscriber_getImageApi.ts",
    //saveAndGetImageApi: "./saveAndGetImageApi.ts",
    //getImageCallApi: "./getImageCallApi.ts",

    /** Commenting out the below files as we don't have pre live set up for woodwing apis and s3 bucket
     * please don't run the below files
     * */
    // getImageListFromWoodWingApi: "./getImageListFromWoodWingApi.ts",
    // getImageFromWoodWingApi: "./getImageFromWoodWingApi.ts",
    // saveImageInToS3BucketApi: "./saveImageInToS3BucketApi.ts",
  },
  output: {
    path: path.join(__dirname, "dist"),
    libraryTarget: "commonjs",
    filename: "[name].js",
  },
  resolve: {
    extensions: [".ts", ".js"],
  },
  module: {
    rules: [
      {
        test: /\.ts$/,
        use: "babel-loader",
      },
    ],
  },
  target: "web",
  externals: /^(k6|https?\:\/\/)(\/.*)?/,
  stats: {
    colors: true,
  },
  plugins: [new CleanWebpackPlugin()],
};
