import { check } from "k6";
import http from "k6/http";
import { Counter } from "k6/metrics";
import { authoringApiUrl, authoringOrigin } from "./envrionments";
// @ts-ignore
import { htmlReport } from "./javascripts/htmlReportFormat";
import { textSummary } from "./javascripts/index";
import { getDate, options as K6Options, setup as authoringLoginAndcookie } from "./utils/helpers";
import { FormData } from '../datasource/k6-multipart.js';
import { SAVE_Image_QUERY } from "./constants/constants";

var myCounter = new Counter("resultCode");
const filepath = '../datasource/test.png';
const fileContent = open(filepath, 'b');
export let options = K6Options;

export function setup() {
  return authoringLoginAndcookie;
}

export default (cookies: string[]) => {
  console.log("Running test saveImageApi");
  const file = http.file(fileContent, 'test.png');
  var formdata = new FormData();
  formdata.append("operations", JSON.stringify(SAVE_Image_QUERY));
  formdata.append("map", "{\"1\":[\"variables.request.file\"]}");
  formdata.append("1", file, filepath);

  let randomUser = cookies[Math.floor(Math.random() * cookies.length)];
  const cookie = randomUser;
  var params: any = {
    headers: {
      "Content-Type": "multipart/form-data; boundary=" + formdata.boundary,
      cookie: `aauth=${cookie}`,
      "accept-encoding": "gzip, deflate, br",
      Accept: "*/*",
      origin: authoringOrigin,
      "sec-fetch-dest": "empty",
      "sec-fetch-mode": "cors",
      "sec-fetch-site": "same-origin",
      "user-agent":
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36",
    },
  };
  const res = http.post(authoringApiUrl, formdata.body(), params);
  const dateMarker = getDate();
  const result = res.status;

  myCounter.add(1, {
    result: `${result}`,
    endTimeStamp: dateMarker.timestamp.toString(),
  });
  check(res, {
    "Save Image Api status is 200": () => result === 200,
  });
};

export function handleSummary(data: any) {
  return {
    "./results/saveImageApi.html": htmlReport(data),
    stdout: textSummary(data, { indent: " ", enableColors: true }),
  };
}

