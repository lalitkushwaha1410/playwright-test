import { check } from "k6";
import { Options } from "k6/options";
import http from "k6/http";
import { Counter } from "k6/metrics";
import { getLoginCookie } from "./utils/authoringlogin";
import { authoringApiUrl, authoringOrigin, authoringLogin } from "./envrionments";
// @ts-ignore
import { htmlReport } from "./javascripts/htmlReportFormat";
import { textSummary } from "./javascripts/index";
import { getDate }from "./utils/helpers";
import {FormData} from '..\\datasource\\k6-multipart.js';
import { SAVE_Image_QUERY } from "./constants/constants";
import { getImageApi } from "./getImageCallApi";

var myCounter = new Counter("resultCode");
const filepath = '../datasource/test.png';
const fileContent = open(filepath, 'b');

export let options: Options = {
  scenarios: {
    constant_request_rate: {
      executor: "constant-arrival-rate",
      rate: 10,
      timeUnit: "1s",
      duration: "5m",
      gracefulStop: "5s",
      preAllocatedVUs: 15,
      maxVUs: 20, // double the max rate vu's
    },
  },
  insecureSkipTLSVerify: true,
  thresholds: {
    http_req_duration: ["p(90) < 1000", "p(95) < 2000", "p(99.9) < 2500", "med<1500"], // med/avg of requests must complete below 1.5s
    http_req_failed: ["rate < 0.01"],
  },
};

// Setup stage - login and set up cookies
export function setup() {
  const cookies: string[] = [];
  for (let user of authoringLogin) {
    const cookie = getLoginCookie(user.user, user.pass);
    if (cookie) {
        cookies.push(cookie);
    }
  }
  return cookies;
}
export default (cookies: string[]) => {
  const file = http.file(fileContent, 'test.png');
  var formdata = new FormData();
  formdata.append("operations", JSON.stringify(SAVE_Image_QUERY));
  formdata.append("map", "{\"1\":[\"variables.request.file\"]}");
  formdata.append("1",file,filepath);
  
  let randomUser = cookies[Math.floor(Math.random() * cookies.length)];
  const cookie = randomUser;
  var params: any = {
    headers: {
      "Content-Type": "multipart/form-data; boundary=" +formdata.boundary,
      cookie: `aauth=${cookie}`,
      "accept-encoding": "gzip, deflate, br",
      Accept: "*/*",
      origin: authoringOrigin,
      "sec-fetch-dest": "empty",
      "sec-fetch-mode": "cors",
      "sec-fetch-site": "same-origin",
      "user-agent":
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36",
    },
  };
  const res = http.post(authoringApiUrl, formdata.body(), params);

   // console.log("response :" + JSON.stringify(res));

    //@ts-ignore
  if(res && res.body && res.body.data)
  {
     //@ts-ignore
    getImageApi(cookie,res.body.data.save.version)
  } 
  const dateMarker = getDate();
  const result = res.status;


  myCounter.add(1, {
    result: `${result}`,
    endTimeStamp: dateMarker.timestamp.toString(),
  });
  check(res, {
    "Save and Get Image Api status is 200": () => result === 200,
  });
};

export function handleSummary(data: any) {
    return {
      "./results/saveAndGetImageApi.html": htmlReport(data),
      stdout: textSummary(data, { indent: " ", enableColors: true }),
    };
  }

