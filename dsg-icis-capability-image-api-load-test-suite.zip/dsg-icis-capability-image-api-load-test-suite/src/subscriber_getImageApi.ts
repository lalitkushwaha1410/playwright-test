// @ts-ignore
global.window = globalThis;
import { check } from "k6";
import http from "k6/http";
import { Counter } from "k6/metrics";
import { getLoginCookie } from "./utils/subscriberlogin";
import { subscriberApiUrl,subscriberOrigin , subscriberLogin } from "./envrionments";
// @ts-ignore
import { htmlReport } from "./javascripts/htmlReportFormat";
import { textSummary } from "./javascripts/index";
import { getDate , options as K6Options} from "./utils/helpers";
import { GET_Image_QUERY } from "./constants/constants";

var myCounter = new Counter("resultCode");
export let options = K6Options;

export function setup() {
  const cookies: string[] = [];
  for (let user of subscriberLogin) {
    const cookie = getLoginCookie(user.user, user.pass);
    if (cookie) {
        cookies.push(cookie);
    }
  }
  return cookies;
}
//@ts-ignore
export default (cookies: string[]) => {
  
  let randomUser = cookies[Math.floor(Math.random() * cookies.length)];
  const cookie = randomUser;

  var params: any = {
    headers: {
      "Content-Type": "application/json",
      cookie: `sauth=${cookie}`,
      "accept-encoding": "gzip, deflate, br",
      Accept: "*/*",
      origin: subscriberOrigin,
      "sec-fetch-dest": "empty",
      "sec-fetch-mode": "cors",
      "sec-fetch-site": "same-origin",
      "user-agent":
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.186 Safari/537.36",
    },
  };

  //@ts-ignore
  const imageQuery = GET_Image_QUERY("0.1");

  const res = http.post(subscriberApiUrl, JSON.stringify(imageQuery), params);
  const dateMarker = getDate();
  const result = res.status;

  myCounter.add(1, {
    result: `${result}`,
    endTimeStamp: dateMarker.timestamp.toString(),
  });
  check(res, {
    "Subscriber Get Image Api status is 200": () => result === 200,
  });
};

export function handleSummary(data: any) {
    return {
      "./results/subscriberGetImageApi.html": htmlReport(data),
      stdout: textSummary(data, { indent: " ", enableColors: true }),
    };
  }
