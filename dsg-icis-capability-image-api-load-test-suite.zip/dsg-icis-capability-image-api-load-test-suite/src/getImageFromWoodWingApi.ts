// @ts-ignore
global.window = globalThis;
import { check } from "k6";
import { Counter } from "k6/metrics";
import { woodwingApiUrl } from "./envrionments";
// @ts-ignore
import { htmlReport } from "./javascripts/htmlReportFormat";
import { textSummary } from "./javascripts/index";
import { getDate, options as K6Options } from "./utils/helpers";
import { setup as woodwingSetup, getWoodwingApiRequest } from "./utils/woodwingUtils";

var myCounter = new Counter("resultCode");
export let options = K6Options;

export function setup() {
  return woodwingSetup();
}

export default function (setupData: any) {
  console.log("Running test getImageFromWoodwingApi");
  const getImageResponse = getWoodwingApiRequest(setupData, `${woodwingApiUrl}/${setupData.imageIds[0]}`);
  check(getImageResponse, {
    'validating image status code 200': (r) => r.status === 200,
    'validating getImageFromWoodwingApi api response time is < 2s': (r) =>
      r.timings.duration < 2000,
    'has Content-Type as image/jpeg': (r) => r.headers['Content-Type'] === 'image/jpeg'
  });

  const dateMarker = getDate();
  const result = getImageResponse.status;

  myCounter.add(1, {
    result: `${result}`,
    endTimeStamp: dateMarker.timestamp.toString(),
  });

}

export function handleSummary(data: any) {
  return {
    "./results/getImageFromWoodWingApi.html": htmlReport(data),
    stdout: textSummary(data, { indent: " ", enableColors: true }),
  };
}