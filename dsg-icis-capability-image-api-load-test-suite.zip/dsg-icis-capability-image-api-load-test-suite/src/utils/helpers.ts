import { Options } from "k6/options";
import { authoringLogin, rateConfigValue } from "../envrionments";
import { getLoginCookie } from "./authoringlogin";

interface DateValue {
  dateString: string;
  timestamp: number;
}

export function getDate() : DateValue {
  const date = new Date();
  return {
    dateString: `${date.getFullYear()}-${date.getMonth()}-${date.getDay()}-${date.getHours()}-${date.getMinutes()}-${date.getSeconds()}`,
    timestamp: Math.floor(date.getTime() / 1000)
  }
}


export const options: Options = {
  scenarios: {
    rateConfigValue
  },
  insecureSkipTLSVerify: true,
  thresholds: {
    http_req_duration: ["p(90) < 1000", "p(95) < 2000", "med<3000"],// med/avg of requests must complete below 1.5s
    http_req_failed: ["rate < 0.01"],
  },
};

//Setup stage - authoring login and set up cookies
export function setup() {
  const cookies: string[] = [];
  for (let user of authoringLogin) {
    const cookie = getLoginCookie(user.user, user.pass);
    if (cookie) {
      cookies.push(cookie);
    }
  }
  return cookies;
}