import http from "k6/http";
import { authoringLogin, woodwingApiUrl } from "../envrionments";
import { getLoginCookie } from "./authoringlogin";

export const woodwingApiUrlList = `${woodwingApiUrl}/list`;

export function getImageUrl(imageId: string) {
  return `${woodwingApiUrl}/${imageId}`;
}

export function getSaveImageUrl(imageId: string) {
  return `${woodwingApiUrl}/save/${imageId}`;
}

export function getParams(cookie: string) {
  return {
    headers: {
      "Content-Type": "application/json",
      cookie: `aauth=${cookie}`,
    },
  };
}

export function setup() {
  const cookies: string[] = [];
  for (let user of authoringLogin) {
    const cookie = getLoginCookie(user.user, user.pass);
    if (cookie) {
      cookies.push(cookie);
    }
  }

  const res = getWoodwingApiRequest({ cookies: cookies }, woodwingApiUrlList);
  const images = JSON.parse(res.body as string);
  let imageIds: string[] = [];
  images.forEach((image: any) => {
    imageIds.push(image.id);
  });

  let setupData = {
    cookies,
    imageIds,
  };
  return setupData;
}

export function getWoodwingApiRequest(setupData: any, URL: string) {
  return http.request('GET', URL, null, getParams(setupData.cookies[0]));
}