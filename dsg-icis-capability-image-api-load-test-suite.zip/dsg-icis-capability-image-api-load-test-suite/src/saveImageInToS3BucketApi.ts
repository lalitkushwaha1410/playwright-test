// @ts-ignore
global.window = globalThis;
import { check } from "k6";
import { Counter } from "k6/metrics";
// @ts-ignore
import { htmlReport } from "./javascripts/htmlReportFormat";
import { textSummary } from "./javascripts/index";
import { getDate, options as K6Options } from "./utils/helpers";
import { getSaveImageUrl, setup as woodwingSetup, getWoodwingApiRequest } from "./utils/woodwingUtils";

var myCounter = new Counter("resultCode");
export let options = K6Options;

export function setup() {
  return woodwingSetup();
}

export default function (setupData: any) {

  const expectedResponseURL = `woodwing/feature-image/${setupData.imageIds[1]}.jpg`;
  const saveImageResponse = getWoodwingApiRequest(setupData, getSaveImageUrl(setupData.imageIds[1]));
  console.log("Running test saveImageInToS3BucketApi");
  check(saveImageResponse, {
    'validating Save image to S3 Bucket status code 200': (r) => r.status === 200,
    'validating saveImageIntOS3Api response time is < 2s': (r) => r.timings.duration < 2000,
    'validating body has feature image url': (r) => r.body === expectedResponseURL
  });

  const dateMarker = getDate();
  const result = saveImageResponse.status;

  myCounter.add(1, {
    result: `${result}`,
    endTimeStamp: dateMarker.timestamp.toString(),
  });
}

export function handleSummary(data: any) {
  return {
    "./results/saveImageInToS3BucketApi.html": htmlReport(data),
    stdout: textSummary(data, { indent: " ", enableColors: true }),
  };
}