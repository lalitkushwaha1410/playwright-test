// @ts-ignore
global.window = globalThis;
import { check } from "k6";
import http from "k6/http";
import { Counter } from "k6/metrics";
import { authoringApiUrl, authoringOrigin } from "./envrionments";
// @ts-ignore
import { htmlReport } from "./javascripts/htmlReportFormat";
import { textSummary } from "./javascripts/index";
import { getDate, options as K6Options, setup as authoringLoginAndcookie } from "./utils/helpers";
import { GET_Image_QUERY } from "./constants/constants";

var myCounter = new Counter("resultCode");
export let options = K6Options;


export function setup() {
  return authoringLoginAndcookie();
}

//@ts-ignore
export default (cookies: string[]) => {

  let randomUser = cookies[Math.floor(Math.random() * cookies.length)];
  const cookie = randomUser;

  var params: any = {
    headers: {
      "Content-Type": "application/json",
      cookie: `aauth=${cookie}`,
      "accept-encoding": "gzip, deflate, br",
      Accept: "*/*",
      origin: authoringOrigin,
      "sec-fetch-dest": "empty",
      "sec-fetch-mode": "cors",
      "sec-fetch-site": "same-origin",
      "user-agent":
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.186 Safari/537.36",
    },
  };

  //@ts-ignore
  const imageQuery = GET_Image_QUERY("0.29");

  const res = http.post(authoringApiUrl, JSON.stringify(imageQuery), params);
  const dateMarker = getDate();
  const result = res.status;

  myCounter.add(1, {
    result: `${result}`,
    endTimeStamp: dateMarker.timestamp.toString(),
  });
  check(res, {
    "Get Image Api status is 200": () => result === 200,
  });
};

export function handleSummary(data: any) {
  return {
    "./results/getImageApi.html": htmlReport(data),
    stdout: textSummary(data, { indent: " ", enableColors: true }),
  };
}