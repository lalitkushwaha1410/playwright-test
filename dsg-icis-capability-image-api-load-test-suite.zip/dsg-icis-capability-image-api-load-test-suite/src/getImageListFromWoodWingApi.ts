// @ts-ignore
global.window = globalThis;
import { check } from "k6";
import { Counter } from "k6/metrics";
// @ts-ignore
import { htmlReport } from "./javascripts/htmlReportFormat";
import { textSummary } from "./javascripts/index";
import { getDate, options as K6Options, setup as authoringLoginAndcookie } from "./utils/helpers";
import { getParams, getWoodwingApiRequest, woodwingApiUrlList } from "./utils/woodwingUtils";

var myCounter = new Counter("resultCode");
export let options = K6Options;

// Setup stage - login and set up cookies
export function setup() {
  return authoringLoginAndcookie();
}

export default (cookies: string[]) => {

  let randomUser = cookies[Math.floor(Math.random() * cookies.length)];
  const cookie = randomUser;
  getParams(cookie);

  const res = getWoodwingApiRequest({ cookies: cookies }, woodwingApiUrlList);
  const dateMarker = getDate();
  const result = res.status;
  myCounter.add(1, {
    result: `${result}`,
    endTimeStamp: dateMarker.timestamp.toString(),
  });

  console.log("Running test getImageListFromWoodWingApi");
  check(res, {
    "validating image List from woodwing Api status code 200": (r) => r.status === 200,
    "validating getImageListFromWoodwingApi api response time is < 2s": (r) =>
      r.timings.duration < 2000,
    "Image List should not be empty": (r) => JSON.parse(r.body) && JSON.parse(r.body).length > 0
  });
}

export function handleSummary(data: any) {
  return {
    "./results/getImageListFromWoodWingApi.html": htmlReport(data),
    stdout: textSummary(data, { indent: " ", enableColors: true }),
  };
}