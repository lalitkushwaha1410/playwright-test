#!/bin/bash
# Install dependencies and execute tests
yarn install && \
yarn add -D @playwright/test && \
yarn add -D cross-env && \
yarn add -D playwright@latest

CLASSNAME=${CLASSNAME:-$1}

if [ "$CLASSNAME" == "comp" ]; then
  yarn test:comp
elif [ "$CLASSNAME" == "performance" ]; then
  yarn test:performance
elif [ "$CLASSNAME" = "all" ]; then
  yarn test:all
else
  echo "Unknown CLASSNAME: $CLASSNAME"
  exit 1
fi