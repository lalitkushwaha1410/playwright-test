
export const GET_ALL_RECORDS = {
  operationName: "GET_ALL_RECORDS",
  variables: {
    "page": {
      "number": 1,
      "size": 10
    },
    "sort": {
      "field": "LAST_UPDATED_ON",
      "order": "DESC"
    },
    "filters": [
      {
        "field": "STATUS",
        "value": "Ready for review"
      }
    ],
    "statuses": [
      "Ready for review",
      "In review",
      "Ready to publish"
    ]
  },
  query: `
          query GET_ALL_RECORDS($page: PageInput!, $sort: SortInput!, $statuses: [String!]!, $filters: [FilterInput!]!) {
            getTaskListRecords(page: $page, sort: $sort, filters: $filters) {
              id
              lastUpdatedOn
              content
              contentType
              market
              location
              lastUpdatedBy
              status
              businessKey
              __typename
            }
            getTaskListStatusCount(statuses: $statuses) {
              status
              count
              __typename
            }
            getTaskListFilters(filters: $filters) {
              contentTypes
              markets
              locations
              lastUpdatedByList
              __typename
            }
          }
  
      `,
};


export const GET_TASKLIST_RECORDS = {
  operationName: "GET_ALL_RECORDS",
  variables: {
    "page": {
      "number": 1,
      "size": 10
    },
    "sort": {
      "field": "LAST_UPDATED_ON",
      "order": "DESC"
    },
    "filters": [
      {
        "field": "STATUS",
        "value": "Ready for review"
      }
    ]
  },
  query: `
          query GET_ALL_RECORDS($page: PageInput!, $sort: SortInput!, $filters: [FilterInput!]!) {
            getTaskListRecords(page: $page, sort: $sort, filters: $filters) {
            id
            lastUpdatedOn
            content
            contentType
            market
            location
            lastUpdatedBy
            status
            businessKey
            __typename
          }
        }
      `,
};


export const GET_STATUS_COUNT = {
  operationName: "GET_ALL_RECORDS",
  variables: {
    "statuses": [
      "Ready for review",
      "In review",
      "Ready to publish"
    ]
  },
  query: `
          query GET_ALL_RECORDS($statuses: [String!]!) {
            getTaskListStatusCount(statuses: $statuses) {
                  status
                  count
                  __typename
                }
        }

      `,
};

export const GET_FILTERS_LIST = {
  operationName: "GET_ALL_RECORDS",
  variables: {
    "filters": [
      {
        "field": "STATUS",
        "value": "Ready for review"
      }
    ]
  },
  query: `
      query GET_ALL_RECORDS($filters: [FilterInput!]!) {
        getTaskListFilters(filters: $filters) {
                      contentTypes
                      markets
                      locations
                      lastUpdatedByList
                      __typename
                    }
        }
      `,
};

export const GET_DATA_WITH_CONTENTTYPE_FILTERS = {
  operationName: "GET_ALL_RECORDS",
  variables: {
    "page": {
      "number": 1,
      "size": 10
    },
    "sort": {
      "field": "LAST_UPDATED_ON",
      "order": "DESC"
    },
    "filters": [
      {
        "field": "STATUS",
        "value": "Ready for review"
      },
      {
        "field": "CONTENT_TYPE",
        "value": [
          "Content"
        ]
      }
    ]
  },
  query: `
          query GET_ALL_RECORDS($page: PageInput!, $sort: SortInput!, $filters: [FilterInput!]!) {
            getTaskListRecords(page: $page, sort: $sort, filters: $filters) {
            id
            lastUpdatedOn
            content
            contentType
            market
            location
            lastUpdatedBy
            status
            businessKey
            __typename
          }
        }
      `,
};


export const GET_DATA_WITH_MARKET_FILTERS = {
  operationName: "GET_ALL_RECORDS",
  variables: {
    "page": {
      "number": 1,
      "size": 10
    },
    "sort": {
      "field": "LAST_UPDATED_ON",
      "order": "DESC"
    },
    "filters": [
      {
        "field": "STATUS",
        "value": "Ready for review"
      },
      {
        "field": "MARKET",
        "value": [
          "Melamine"
        ]
      }
    ],
  },
  query: `
          query GET_ALL_RECORDS($page: PageInput!, $sort: SortInput!, $filters: [FilterInput!]!) {
            getTaskListRecords(page: $page, sort: $sort, filters: $filters) {
            id
            lastUpdatedOn
            content
            contentType
            market
            location
            lastUpdatedBy
            status
            businessKey
            __typename
          }
        }
      `,
};

export const GET_DATA_WITH_LOCATION_FILTERS = {
  operationName: "GET_ALL_RECORDS",
  variables: {
    "page": {
      "number": 1,
      "size": 10
    },
    "sort": {
      "field": "LAST_UPDATED_ON",
      "order": "DESC"
    },
    "filters": [
      {
        "field": "STATUS",
        "value": "Ready for review"
      },
      {
        "field": "LOCATION",
        "value": [
          "Asia-Pacific"
        ]
      }
    ],
  },
  query: `
          query GET_ALL_RECORDS($page: PageInput!, $sort: SortInput!, $filters: [FilterInput!]!) {
            getTaskListRecords(page: $page, sort: $sort, filters: $filters) {
            id
            lastUpdatedOn
            content
            contentType
            market
            location
            lastUpdatedBy
            status
            businessKey
            __typename
          }
        }
      `,
};

export const GET_DATA_WITH_LASTUPDATEDBY_FILTERS = {
  operationName: "GET_ALL_RECORDS",
  variables: {
    "page": {
      "number": 1,
      "size": 10
    },
    "sort": {
      "field": "LAST_UPDATED_ON",
      "order": "DESC"
    },
    "filters": [
      {
        "field": "STATUS",
        "value": "Ready for review"
      },
      {
        "field": "LAST_UPDATED_BY",
        "value": [
          "wf_reviewer"
        ]
      }
    ],
  },
  query: `
          query GET_ALL_RECORDS($page: PageInput!, $sort: SortInput!, $filters: [FilterInput!]!) {
            getTaskListRecords(page: $page, sort: $sort, filters: $filters) {
            id
            lastUpdatedOn
            content
            contentType
            market
            location
            lastUpdatedBy
            status
            businessKey
            __typename
          }
        }
      `,
};