import { shared } from '../../fixtures/constants/shared';
import { VideoPage } from '../../support/ui/pages/video.po';

describe('E2E Authoring and Subscriber Automation Test for Video Tool', { testIsolation: false }, () => {
  const videoPage = new VideoPage();
  var env = Cypress.env('ENV');

  beforeEach(() => {
    cy.viewport(1280, 720);
    cy.log('Running in ' + env + ' environment');
    cy.clearAllSessionStorage();
    cy.clearAllCookies();
    cy.visit(shared.environment.image.authoring[env]);
    cy.Login(shared.users.authoringUser.username, Cypress.env('password'));
    cy.wait(20000);
  });

  // it('Validate Creating a new intelligence page', () => {
  //   cy.SearchExistingORCreateNewIntelligencePage();
  //   cy.screenshot('Creating Intelligence Page');
  // });

  // it('Validate Adding a Blank Video Card', () => {
  //   cy.SearchExistingORCreateNewIntelligencePage();
  //   videoPage.clickAtContentBlockButton();
  //   cy.wait(2000);
  //   videoPage.selectVideoCard();
  //   cy.screenshot('Creating Blank Video Card');
  //   videoPage.deleteContentBlock();
  // });

  // it('Validate Preview for Video and Add Video to Page', () => {
  //   cy.SearchExistingORCreateNewIntelligencePage();
  //   videoPage.clickAtContentBlockButton();
  //   cy.wait(2000);
  //   videoPage.selectVideoCard();
  //   videoPage.clickOnAddVideo();
  //   videoPage.enterVideoURL();
  //   videoPage.clickOnPopupNextButton();
  //   videoPage.validatePreviewDeleteButton();
  //   videoPage.clickOnPopupAddToPageButton();
  //   cy.screenshot('Validate Video added to Page');
  //   cy.wait(3000);
  // });

  // it('Validate the Video saved in pause mode and once played user should able to edit the play settings', () => {
  //   cy.SearchExistingORCreateNewIntelligencePage();
  //   cy.wait(5000);
  //   videoPage.playSavedVideo();
  //   videoPage.validatePlayVideoScreenDisplay();
  //   videoPage.mouseHoverVideoAndPauseVideo();
  //   videoPage.validateVideoQualityChangeIcon();
  //   videoPage.validateVideoVolumeChangeIcon();
  //   videoPage.validateVideoFullScreenIcon();
  // });

  // it('Validate title section and Saving Title for the Video card', () => {
  //   cy.SearchExistingORCreateNewIntelligencePage();
  //   cy.wait(6000);
  //   videoPage.validateVideoTitlePlacehoder();
  //   //videoPage.validateVideoTitleHelpText();
  //   videoPage.addHeaderToVideo();
  //   videoPage.validateTitleSaved();
  //   cy.screenshot('Validate Title added for Video Card');
  //   cy.wait(1000);
  // })

  // it('Validate Footer section and Saving Footer notes for the Video card', () => {
  //   cy.SearchExistingORCreateNewIntelligencePage();
  //   cy.wait(6000);
  //   videoPage.validateVideoFooterPlaceholder();
  //   //videoPage.validateVideoFooterHelpText();
  //   videoPage.addFooterToVideo();
  //   videoPage.validateFootnotesSaved();
  //   cy.screenshot('Validate Footnotes added for Video Card');
  //   cy.wait(1000);
  // });

  // This test case also cover the adding video to the authoring page
  it('Validate Preview for Video and Add Video to Page and verify edit button for noaccess user', () => {
    cy.SearchExistingORCreateNewIntelligencePage();
    videoPage.clickAtContentBlockButton();
    cy.wait(2000);
    videoPage.selectVideoCard();
    videoPage.clickOnAddVideo();
    videoPage.enterVideoURL();
    videoPage.clickOnPopupNextButton();
    videoPage.clickOnPopupAddToPageButton();
    cy.screenshot('Validate Video added to Page');
    cy.wait(3000);
    // Login with user with no access
    cy.clearAllSessionStorage();
    cy.clearAllCookies();
    cy.visit(shared.environment.image.authoring[env]);
    cy.Login(shared.users.noaccessUser.username, Cypress.env('password'));
    cy.reload();
    cy.wait(4000);  
     cy.get('a').contains('Mercury E2E Test').click();
         // Check if the edit button is not visible
    videoPage.verifyeditbuttonvisibility();
    cy.screenshot('Validate edit button visibility for different user');
  });

  it('Publish the Authoring Page', () => {
    cy.SearchExistingORCreateNewIntelligencePage();
    videoPage.sendForReviewPage();
    cy.wait(8000);
    //cy.SearchExistingORCreateNewIntelligencePage();
    videoPage.publishAuthoringPage();
    cy.screenshot('Publish Authoring Page');
  });

  // Subscriber view test validations

  // it('Login into Subscriber View', () => {
  //   cy.clearAllSessionStorage();
  //   cy.clearAllCookies();
  //   var env = Cypress.env('ENV');
  //   cy.log('Running in ' + env + 'environment');
  //   cy.visit(shared.environment.subscriber[env]);
  //   cy.screenshot('Login into Subscriber View');
  //   cy.Subscriber_login(shared.users.subscriberUser.username, Cypress.env('password'));
  // });

  // it('Navigating to Intelligence Page in Subscriber View', () => {
  //   cy.clearAllSessionStorage();
  //   cy.clearAllCookies();
  //   cy.visit(shared.environment.subscriber[env]);
  //   cy.Subscriber_login(shared.users.subscriberUser.username, Cypress.env('password'));
  //   cy.screenshot('Navigating to Intelligence Page in Subscriber View');
  //   videoPage.openIntelligencePage();
  // });

  it('Validate video in the Subscriber View', () => {
    cy.clearAllSessionStorage();
    cy.clearAllCookies();
    cy.visit(shared.environment.subscriber[env]);
    cy.Subscriber_login(shared.users.subscriberUser.username, Cypress.env('password'));
    cy.CheckDuplicateLogin();
    videoPage.openIntelligencePage();
    videoPage.findVideoInSubscriber();
    cy.screenshot('Validate Video in the Subscriber View');
  });

  // it('Validate Title and Footnotes for Video in Subscriber View', () => {
  //   cy.clearAllSessionStorage();
  //   cy.clearAllCookies();
  //   cy.visit(shared.environment.subscriber[env]);
  //   cy.Subscriber_login(shared.users.subscriberUser.username, Cypress.env('password'));
  //   videoPage.openIntelligencePage();
  //   videoPage.validatetitleInSubscriberView();
  //   videoPage.validateFootnotesInSubscriberView();
  //   cy.screenshot('Validate Title and Footnotes for Video in Subscriber View');
  // });

  it('Delete Intelligence Page', () => {
    videoPage.DeleteRecord();
  });
});
