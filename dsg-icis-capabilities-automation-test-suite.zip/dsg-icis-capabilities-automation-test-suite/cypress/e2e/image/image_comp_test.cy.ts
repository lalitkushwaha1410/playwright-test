import { shared } from '../../fixtures/constants/shared';
import { ImageCardPage } from '../../support/ui/pages/imageCard.po';

describe('Component Test for Image card', { testIsolation: false }, () => {
  const imageCardPage = new ImageCardPage();
  beforeEach(() => {
    cy.viewport(1280, 720);
  });

  beforeEach(() => {
    cy.clearAllSessionStorage();
    cy.clearAllCookies();
    const env = Cypress.env('ENV');
    cy.log('Running in ' + env + ' environment');
    cy.visit(shared.environment.image.image_testHarness[env]);
    cy.Login(shared.users.authoringUser.username, Cypress.env('password'));
    cy.reload();
    cy.wait(4000);
    cy.waitForVisible('button:contains("Add image")', 15000);
  });

  it('Validate Error Message for Image Format other than JPEG or PNG', () => {
    cy.screenshot('Login into TestHarness Environment');
    imageCardPage.clickOnAddImage();
    imageCardPage.selectAndUploadUnsupportedImage();
    cy.wait(1000);
    imageCardPage.invalidFormatError();
    imageCardPage.validateCancelAndBrowseButtons();
    cy.screenshot('Validate Error Message for Image Format other than JPEG or PNG');
    imageCardPage.closePopupDialog();
  });

  it('Validate Error Message for Image Size greater than 1MB', () => {
    imageCardPage.clickOnAddImage();
    imageCardPage.selectAndUploadLargeSizeImage();
    cy.wait(1000);
    imageCardPage.imageSizeError();
    imageCardPage.validateCancelAndBrowseButtons();
    cy.screenshot('Validate Error Message for Image Size greater than 1MB');
    imageCardPage.closePopupDialog();
  });

  it('Validate adding a image to the page', () => {
    imageCardPage.clickOnAddImage();
    imageCardPage.selectAndUploadValidImage();
    cy.wait(1000);
    imageCardPage.imagewarningMessage();
    imageCardPage.clickAddToPageButton();
    imageCardPage.validateImageisAdded();
    cy.screenshot('Validate adding a image to the page');
  });

  it('Validate title section and Saving Title for the image card', () => {
    imageCardPage.clickOnAddImage();
    imageCardPage.selectAndUploadValidImage();
    cy.wait(1000);
    imageCardPage.imagewarningMessage();
    imageCardPage.clickAddToPageButton();
   // imageCardPage.validateImageTitleHelpText();
    imageCardPage.addingTitletoImage();
    imageCardPage.validateTitleSaved();
    cy.screenshot('Validate title section and Saving Title for the image card');
  });

  it('Validate Footer section and Saving Footer notes for the image card', () => {
    imageCardPage.clickOnAddImage();
    imageCardPage.selectAndUploadValidImage();
    cy.wait(1000);
    imageCardPage.imagewarningMessage();
    imageCardPage.clickAddToPageButton();
    //imageCardPage.validateImageFooterHelpText();
    imageCardPage.addingFooterToImage();
    imageCardPage.validateFootnotesSaved();
    cy.screenshot('Validate Footer section and Saving Footer notes for the image card');
    cy.wait(1000);
  });

  it('Switching to Subscriber view', () => {
    imageCardPage.clickOnAddImage();
    imageCardPage.selectAndUploadValidImage();
    cy.wait(1000);
    imageCardPage.imagewarningMessage();
    imageCardPage.clickAddToPageButton();
    imageCardPage.addingTitletoImage();
    imageCardPage.addingFooterToImage();
    imageCardPage.switchToSubsciberView();
    cy.screenshot('Switching to Subscriber view');
    cy.Subscriber_login(shared.users.subscriberUser.username, Cypress.env('password'));
  });

  it('Validate Image in the Subscriber View', () => {
    imageCardPage.clickOnAddImage();
    imageCardPage.selectAndUploadValidImage();
    cy.wait(1000);
    imageCardPage.imagewarningMessage();
    imageCardPage.clickAddToPageButton();
    imageCardPage.addingTitletoImage();
    imageCardPage.addingFooterToImage();
    imageCardPage.switchToSubsciberView();
    cy.Subscriber_login(shared.users.subscriberUser.username, Cypress.env('password'));
    imageCardPage.findImageInSubscriber();
    imageCardPage.validateImageinSubscriberView();
    cy.screenshot('Validate Image in the Subscriber View');
  });

  it('Validate Title and Footnotes for Image in Subscriber View', () => {
    imageCardPage.clickOnAddImage();
    imageCardPage.selectAndUploadValidImage();
    cy.wait(1000);
    imageCardPage.imagewarningMessage();
    imageCardPage.clickAddToPageButton();
    imageCardPage.addingTitletoImage();
    imageCardPage.addingFooterToImage();
    imageCardPage.switchToSubsciberView();
    cy.Subscriber_login(shared.users.subscriberUser.username, Cypress.env('password'));
    imageCardPage.validateImagetitleInSubscriberView();
    imageCardPage.validateFootnotesInSubscriberView();
    cy.screenshot('Validate Title and Footnotes for Image in Subscriber View');
  });

});
