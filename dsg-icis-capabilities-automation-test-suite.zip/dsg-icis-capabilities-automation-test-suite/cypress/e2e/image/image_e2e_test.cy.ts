import { shared } from '../../fixtures/constants/shared';
import { ImageCardPage } from '../../support/ui/pages/imageCard.po';

describe('E2E Authoring and Subscriber Automation Test for Image Tool', { testIsolation: false }, () => {
  const imageCardPage = new ImageCardPage();
  const env = Cypress.env('ENV');

  beforeEach('Login into Authoring Site', () => {
    cy.viewport(1280, 720);
    cy.log('Running in ' + env + ' environment');
    cy.clearAllSessionStorage();
    cy.clearAllCookies();
    cy.visit(shared.environment.image.authoring[env]);
    cy.Login(shared.users.authoringUser.username, Cypress.env('password'));
    cy.wait(20000);
  });

//   it('Validate Creating a new intelligence page', () => {
//     cy.SearchExistingORCreateNewIntelligencePage();
//     cy.url().should('include', 'authoring')
//     cy.screenshot('Creating Intelligence Page');
//   });

//   it('Validate Adding a blank Image card', () => {
//     cy.SearchExistingORCreateNewIntelligencePage();
//     imageCardPage.clickAtContentBlockButton();
//     cy.wait(1000);
//     imageCardPage.selectImageCard();
//     cy.screenshot('Creating Blank Image Card');
//     imageCardPage.deleteContentBlock();
//   });

//   it('Validate Error Message for Image Format other than JPEG or PNG', () => {
//     cy.SearchExistingORCreateNewIntelligencePage();
//     imageCardPage.clickAtContentBlockButton();
//     cy.wait(1000);
//     imageCardPage.selectImageCard();
//     imageCardPage.clickOnAddImage();
//     imageCardPage.selectAndUploadUnsupportedImage();
//     cy.wait(1000);
//     imageCardPage.invalidFormatError();
//     imageCardPage.validateCancelAndBrowseButtons();
//     cy.screenshot('Validate Error Message for Image Format other than JPEG or PNG');
//     imageCardPage.closePopupDialog();
//     imageCardPage.deleteContentBlock();
//   });

//  it('Validate Error Message for Image Size greater than 1MB', () => {
//     cy.SearchExistingORCreateNewIntelligencePage();
//     imageCardPage.clickAtContentBlockButton();
//     cy.wait(1000);
//     imageCardPage.selectImageCard();
//     imageCardPage.clickOnAddImage();
//     imageCardPage.selectAndUploadLargeSizeImage();
//     cy.wait(1000);
//     imageCardPage.imageSizeError();
//     imageCardPage.validateCancelAndBrowseButtons();
//     cy.screenshot('Validate Error Message for Image Size greater than 1MB');
//     imageCardPage.closePopupDialog();
//     imageCardPage.deleteContentBlock();
//   });

//   it('Validate adding a image to the page', () => {
//     cy.SearchExistingORCreateNewIntelligencePage();
//     imageCardPage.clickAtContentBlockButton();
//     cy.wait(1000);
//     imageCardPage.selectImageCard();
//     imageCardPage.clickOnAddImage();
//     imageCardPage.selectAndUploadValidImage();
//     cy.wait(1000);
//     imageCardPage.imagewarningMessage();
//     imageCardPage.clickAddToPageButton();
//     imageCardPage.validateImageisAdded();
//     cy.screenshot('Validate adding a image to the page');
    
//   });

//   it('Validate title section and Saving Title for the image card', () => {
//     cy.SearchExistingORCreateNewIntelligencePage();
//     imageCardPage.validateImageTitlePlacehoder();
//     //imageCardPage.validateImageTitleHelpText();
//     imageCardPage.addingTitletoImage();
//     imageCardPage.validateTitleSaved();
//     cy.screenshot('Validate title section and Saving Title for the image card');
//   });

//   it('Validate Footer section and Saving Footer notes for the image card', () => {
//     cy.SearchExistingORCreateNewIntelligencePage();
//     imageCardPage.validateImageFooterPlaceholder();
//     //imageCardPage.validateImageFooterHelpText();
//     imageCardPage.addingFooterToImage();
//     imageCardPage.validateFootnotesSaved();
//     cy.wait(1000);
//     cy.screenshot('Validate Footer section and Saving Footer notes for the image card');
//   });

// This test case also cover the adding image to the authoring page
  it('Validate adding image and verify edit button for noaccess user', () => {
    cy.SearchExistingORCreateNewIntelligencePage();
    imageCardPage.clickAtContentBlockButton();
    cy.wait(1000);
    imageCardPage.selectImageCard();
    imageCardPage.clickOnAddImage();
    imageCardPage.selectAndUploadValidImage();
    cy.wait(1000);
    imageCardPage.imagewarningMessage();
    imageCardPage.clickAddToPageButton();
    imageCardPage.validateImageisAdded();
    // Login with user with no access
    cy.clearAllSessionStorage();
    cy.clearAllCookies();
    cy.visit(shared.environment.image.authoring[env]);
    cy.Login(shared.users.noaccessUser.username, Cypress.env('password'));
    cy.reload();
    cy.wait(4000);  
     cy.get('a').contains('Mercury E2E Test').click();
         // Check if the edit button is not visible
     imageCardPage.verifyeditbuttonvisibility();
    cy.screenshot('Validate edit button visibility for different user');
  });

  it('Publish the Authoring Page', () => {
    cy.SearchExistingORCreateNewIntelligencePage();
    imageCardPage.sendForReviewPage();
    cy.wait(5000);
    //cy.SearchExistingORCreateNewIntelligencePage();
    imageCardPage.publishAuthoringPage();
    cy.screenshot('Publish Authoring Page');
  });

  // it('Login into Subscriber View', () => {
  //   cy.clearAllSessionStorage();
  //   cy.clearAllCookies();
  //   var env = Cypress.env('ENV');
  //   cy.log('Running in ' + env + 'environment');
  //   cy.visit(shared.environment.subscriber[env]);
  //   cy.screenshot('Login into Subscriber View');
  //   cy.Subscriber_login(shared.users.subscriberUser.username, Cypress.env('password'));
  // });

  // it('Navigating to Intelligence Page in Subscriber View', () => {
  //   cy.clearAllSessionStorage();
  //   cy.clearAllCookies();
  //   cy.visit(shared.environment.subscriber[env]);
  //   cy.Subscriber_login(shared.users.subscriberUser.username, Cypress.env('password'));
  //   cy.screenshot('Navigating to Intelligence Page in Subscriber View');
  //   imageCardPage.openIntelligencePage();
  // });

  it('Validate Image in the Subscriber View', () => {
    cy.clearAllSessionStorage();
    cy.clearAllCookies();
    cy.visit(shared.environment.subscriber[env]);
    cy.Subscriber_login(shared.users.subscriberUser.username, Cypress.env('password'));
    cy.CheckDuplicateLogin();
    imageCardPage.openIntelligencePage();
    imageCardPage.findImageInSubscriber();
    imageCardPage.validateImageinSubscriberView();
    cy.screenshot('Validate Image in the Subscriber View');
  });

  // it('Validate Title and Footnotes for Image in Subscriber View', () => {
  //   cy.clearAllSessionStorage();
  //   cy.clearAllCookies();
  //   cy.visit(shared.environment.subscriber[env]);
  //   cy.Subscriber_login(shared.users.subscriberUser.username, Cypress.env('password'));
  //   imageCardPage.openIntelligencePage();
  //   imageCardPage.validateImagetitleInSubscriberView();
  //   imageCardPage.validateFootnotesInSubscriberView();
  //   cy.screenshot('Validate Title and Footnotes for Image in Subscriber View');
  // });

  it('Delete Intelligence Page', () => {
    imageCardPage.DeleteRecord();
  });

});
