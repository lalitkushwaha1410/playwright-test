export type TEnvironments = {
  local: string;
  systest: string;
  staging: string;
  integration: string;
  performance: string;
};
