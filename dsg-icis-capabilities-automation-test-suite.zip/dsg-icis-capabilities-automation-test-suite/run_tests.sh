#!/bin/bash
# Install dependencies and execute tests

#yarn "$CLASSNAME"


# Enhanced debugging
echo "================================================================"
echo "🔍 ENVIRONMENT & TEST EXECUTION DEBUGGING"
echo "================================================================"
echo "CLASSNAME environment variable: '$CLASSNAME'"
echo "ENV_NAME environment variable: '$ENV_NAME'"
echo "================================================================"

# Use environment variable with fallback to command-line argument
CLASSNAME="${CLASSNAME:-$1}"
echo "🧪 FINAL DECISION: Running tests for CLASSNAME: '$CLASSNAME'"
echo "================================================================"

if [ "$CLASSNAME" == "image-comp" ]; then
  #echo "Running Cypress Tests with spec file: $CLASSNAME"
  yarn image-comp
elif [ "$CLASSNAME" == "image-e2e" ]; then
  yarn image-e2e
elif [ "$CLASSNAME" == "all" ]; then
  yarn all
elif [ "$CLASSNAME" == "podcast-comp" ]; then
  yarn podcast-comp
elif [ "$CLASSNAME" == "podcast-e2e" ]; then
  yarn podcast-e2e
elif [ "$CLASSNAME" == "video-comp" ]; then
  yarn video-comp
elif [ "$CLASSNAME" == "video-e2e" ]; then
  yarn video-e2e
elif [ "$CLASSNAME" == "all-e2e" ]; then
  yarn all-e2e
elif [ "$CLASSNAME" == "all-comp" ]; then
  yarn all-comp
else
  echo "❌ Unknown CLASSNAME: $CLASSNAME"
  exit 1
fi