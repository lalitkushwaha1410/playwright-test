const capabilityId = "f086d013-da09-47f5-9ccb-a071ca31f071";
const pageId = "test-page";
const podcastURL = "<iframe src='https://podomatic.com/embed/html5/episode/10549793' height='208' width='504'frameborder='0' marginheight='0' marginwidth='0' scrolling='no' allowfullscreen></iframe>";

export const SAVE_PODCAST_QUERY = {
  operationName: "save",
  variables: {
    request: {
      title: "",
      footnote: "",
      capabilityId,
      pageId,
      designType: "",
      podcastURL,
    },
  },
  query: `
        mutation save ($request: SavePodcastRequestDtoInput!) {
            save (request: $request) {
                id
                version
                title
                footnote
                podcastURL
                designType
                __typename
            }
        }
    `,
};

export const GET_PODCAST_QUERY = (version: string) => {
  //operationName: "get",
  return {
    variables: {
      capabilityId,
      pageId,
      version,
    },
    query: `
        query get($capabilityId: String!, $pageId: String!, $version: String!) {
          get(capabilityId: $capabilityId, pageId: $pageId, version: $version) {
            id
            version
            title
            footnote
            podcastURL
            __typename
          }
        }
    `,
  }
};

