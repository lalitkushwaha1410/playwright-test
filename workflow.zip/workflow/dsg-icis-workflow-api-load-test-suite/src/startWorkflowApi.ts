import { check } from "k6";
import { Options } from "k6/options";
import http from "k6/http";
import { Counter } from "k6/metrics";
//import { getLoginCookie } from "./login";
import { authoringApiUrl, authoringOrigin,rateConfigValue } from "./envrionments";
// @ts-ignore
import { htmlReport } from "./javascripts/htmlReportFormat";
import { textSummary } from "./javascripts/index";
import getDate from "./utils/helpers";
import { START_WORKFLOW_QUERY } from "./constants/constants";

var myCounter = new Counter("result-code");

export let options: Options = {
  scenarios: {
    rateConfigValue
  },
  insecureSkipTLSVerify: true,
  thresholds: {
  //  http_req_duration: ["p(90) < 500", "p(95) < 800", "p(99) < 2000", "med < 600"], // med/avg of requests must complete below 1.5s
    http_req_failed: ["rate < 0.01"],
  },
};

// Setup stage - login and set up cookies
/*export function setup() {
  const cookies: string[] = [];
  for (let user of authoringLogin) {
    const cookie = getLoginCookie(user.user, user.pass);
    if (cookie) {
        cookies.push(cookie);
    }
  }
  return cookies;
}*/
export default (cookies: string[]) => {
  
  //let randomUser = cookies[Math.floor(Math.random() * cookies.length)];
  //const cookie = randomUser;
  var params: any = {
    headers: {
      "Content-Type": "application/json",
      cookie: `aauth=CfDJ8JpFDamSCAxMo39bTew9h0hkwgC_JlieLFXtM3y1FoPe6xNNBCbEldsj4EiC13AYu5Zv5ydDozBkrGYWOqH78VAuiySJLSg10JeV2Uk-UXp8vg_MMD3qrPFL0cSmWEG_69Ccu8BqZdEyfSupxRQsQi-I_a1z9OfsqYPduinzef9CjNiT0MTJtIn0Bz758mKzotp3Lt_c4oxEcXp0UBO3Z28jzakX0Pf4G6clWgevudPWjQMByNwFktnTpXmhlsuLEsrv9Uj8u2asrDCYwBWR9wkh7wlBeauW-P9871ZcTmBQ`,
      "initialStatus":"DRAFT",
      "testHarness":"TRUE",
      "workspaceId":"intelligence",
      "accept-encoding": "gzip, deflate, br",
      Accept: "*/*",
      origin: authoringOrigin,
      "sec-fetch-dest": "empty",
      "sec-fetch-mode": "cors",
      "sec-fetch-site": "same-origin",
      "user-agent":
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36",
    },
  };
  const workflowQuery = START_WORKFLOW_QUERY;
  const res = http.post(
    authoringApiUrl,
    JSON.stringify(workflowQuery),
    params
  );
  console.log("workflowStartQuery- "+ JSON.stringify(workflowQuery));
  const jsonBody = res.body;
  if (jsonBody) {
    const data = JSON.parse(jsonBody as string);
    console.log("startworkflowAPI response - "+ JSON.stringify(data));
  };
  const dateMarker = getDate();
  const result = res.status;

  myCounter.add(1, {
    result: `${result}`,
    endTimeStamp: dateMarker.timestamp.toString(),
  });
  check(res, {
    "Start Workflow API status is 200": () => result === 200,
  });
};

export function handleSummary(data: any) {
    return {
      "./results/startWorkflowApi.html": htmlReport(data),
      stdout: textSummary(data, { indent: " ", enableColors: true }),
    };
  }