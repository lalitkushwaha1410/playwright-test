import { test, expect } from "@playwright/test";
import { user } from "../testdata/users";
import { env } from "../testdata/environments";
import { LoginPage } from "../pages/LoginPage";
import { TestHarnessPage } from "../pages/TestHarnessPage";
import {constanttext} from "../testdata/constants";

test.describe("Workflow component tests", async () => {
  let testharnessPage: TestHarnessPage;
  let loginPage: LoginPage;

  test.beforeEach(async ({ page }) => {
   // loginPage = await new LoginPage(page);
    testharnessPage = await new TestHarnessPage(page);
    await testharnessPage.URLToTestharness();
  });

  test("Create New page", async ({page,}) => {
    await testharnessPage.startNewExpressWorkflow();
    await testharnessPage.verify_Status("Draft");
    await testharnessPage.verify_ActionButton("Publish");
  });

  test("Publish page", async ({page,}) => {
    await testharnessPage.startNewExpressWorkflow();
    await testharnessPage.click_ActionButton("Publish");
    await testharnessPage.click_submitondialog();
    await testharnessPage.validatepopupafterpublish();
    await testharnessPage.verify_Status("Published");
  });


});
