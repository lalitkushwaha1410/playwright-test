#!/bin/bash

# Install dependencies and execute tests
yarn install && \
yarn add -D @playwright/test && \
yarn add -D cross-env && \
yarn add -D playwright@latest && \

CLASSNAME=${CLASSNAME:-$1}

if [ "$CLASSNAME" == "comp-express" ]; then
  yarn test:comp-express
elif [ "$CLASSNAME" == "comp-pricing" ]; then
  yarn test:comp-pricing
elif [ "$CLASSNAME" == "comp-content" ]; then
  yarn test:comp-content
elif [ "$CLASSNAME" == "e2e" ]; then
  yarn test:e2e-topics
elif [ "$CLASSNAME" == "visual-topics" ]; then
  yarn test:visual-topics
elif [ "$CLASSNAME" == "visual-pricing" ]; then
  yarn test:visual-pricing
elif [ "$CLASSNAME" == "visual-content" ]; then
  yarn test:visual-content
elif [ "$CLASSNAME" == "comp-all" ]; then
  yarn test:comp-all
elif [ "$CLASSNAME" == "all" ]; then
  yarn test:all
elif [ "$CLASSNAME" == "comp-topics" ]; then
  yarn test:topics
elif [ "$CLASSNAME" == "generic-advance" ]; then
  yarn test:comp-generic-advance
elif [ "$CLASSNAME" == "generic-simple" ]; then
  yarn test:comp-generic-simple
else
  echo "Unknown CLASSNAME: $CLASSNAME"
  exit 1
fi