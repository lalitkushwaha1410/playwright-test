const capabilityId = "fb8cfe69-845c-4e62-8fab-9232f388dac0";
const pageId = "test-page";
const videoURL = "https://video.icis.com/watch/y77vAdtXAHyg82UHRCcLeg";

export const SAVE_VIDEO_QUERY = {
  operationName: "save",
  variables: {
    request: {
      title: "",
      footnote: "",
      capabilityId,
      pageId,
      videoURL,
    },
  },
  query: `
        mutation save ($request: SaveVideoRequestDtoInput!) {
            save (request: $request) {
                id
                version
                title
                footnote
                videoURL
                __typename
            }
        }
    `,
};

export const GET_VIDEO_QUERY = (version: string) => {
  //operationName: "get",
  return {
    variables: {
      capabilityId,
      pageId,
      version,
    },
    query: `
        query get($capabilityId: String!, $pageId: String!, $version: String!) {
          get(capabilityId: $capabilityId, pageId: $pageId, version: $version) {
            id
            version
            title
            footnote
            videoURL
            __typename
          }
        }
    `,
  }
};

export const AUTHORING_GET_INFOGRAM_QUERY = (version: string) => {
  //operationName: "get",
  return {
    variables: {
      capabilityId,
      pageId,
      version,
    },
    query: `
        query get($capabilityId: String!, $pageId: String!, $version: String!) {
          get(capabilityId: $capabilityId, pageId: $pageId, version: $version) {
            id
            version
            title
            footnote
            videoURL
            __typename
          }
        }
    `,
  }
};
