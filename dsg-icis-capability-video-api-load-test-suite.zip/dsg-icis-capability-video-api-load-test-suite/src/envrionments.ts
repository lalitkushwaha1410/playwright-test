import { Scenario } from "k6/options";

type Env = "systest" | "performance" | "staging";
type Rate = "1" | "10" | "20" | "30" | "40";

const authoringLogins = [
  {
    user: "cha\\SptCmsTestEditor@cha.rbxd.ds",
    pass: "Passw0rd",
  },
];

const subscriberSystestStagingLogins = [
  {
    user: "chubtestuser@icis.com",
    pass: "Passw0rd",
  },
];

const subscriberPerformanceLogins = [
  {
    user: "3480245@rbi-viper.com",
    pass: "Passw0rd",
  },
];

const environments = {
  systest: {
    authoringLoginUrl: "https://authoring.systest.cha.rbxd.ds/mfe/video/authoring/",
    subscriberLoginUrl: "https://subscriber.systest.genesis.cha.rbxd.ds/home/intelligence",
    authoringApiUrl: "https://authoring.systest.cha.rbxd.ds/api/video/v1/graphql",
    subscriberApiUrl: "https://subscriber.systest.genesis.cha.rbxd.ds/api/video/v1/graphql",
    webhook:
      "https://authoring.systest.cha.rbxd.ds/api/video/v1/webhooks/",
    authoringOrigin: "https://authoring.systest.cha.rbxd.ds",
    subscriberOrigin: "https://subscriber.systest.genesis.cha.rbxd.ds",
    referer: "",
    authoringLogins: authoringLogins,
    subscriberLogins: subscriberSystestStagingLogins,
  },
  staging: {
    authoringLoginUrl: "https://authoring.staging.cha.rbxd.ds/mfe/video/authoring/",
    subscriberLoginUrl: "https://subscriber.staging.genesis.cha.rbxd.ds/home/intelligence",
    authoringApiUrl: "https://authoring.staging.cha.rbxd.ds/api/video/v1/graphql",
    subscriberApiUrl: "https://subscriber.staging.genesis.cha.rbxd.ds/api/video/v1/graphql",
    webhook: "https://authoring.staging.cha.rbxd.ds/api/video/v1/webhooks/",
    authoringOrigin: "https://authoring.staging.cha.rbxd.ds",
    subscriberOrigin: "https://subscriber.staging.genesis.cha.rbxd.ds",
    referer: "",
    authoringLogins: authoringLogins,
    subscriberLogins: subscriberSystestStagingLogins,
  },
  performance: {
    authoringLoginUrl: "https://authoring.performance.cha.rbxd.ds/mfe/video/authoring/",
    subscriberLoginUrl: "https://subscriber.performance.genesis.cha.rbxd.ds/home/intelligence",
    authoringApiUrl: "https://authoring.performance.cha.rbxd.ds/api/video/v1/graphql",
    subscriberApiUrl: "https://subscriber.performance.genesis.cha.rbxd.ds/api/video/v1/graphql",
    webhook:
      "https://authoring.performance.cha.rbxd.ds/api/video/v1/webhooks/",
    authoringOrigin: "https://authoring.performance.cha.rbxd.ds",
    subscriberOrigin: "https://subscriber.performance.genesis.cha.rbxd.ds",
    referer: "",
    authoringLogins: authoringLogins,
    subscriberLogins: subscriberPerformanceLogins,
  },
};

interface RateConfig {
  1: Scenario;
  10: Scenario;
  20: Scenario;
  30: Scenario;
  40: Scenario;
}

const loadTestConfig: RateConfig = {
  1: {
    executor: "constant-arrival-rate",
    rate: 1,
    timeUnit: "1s",
    duration: "10s",
    gracefulStop: "5s",
    preAllocatedVUs: 5,
    maxVUs: 5, // double the max rate vu's
  },
  10: {
    executor: "constant-arrival-rate",
    rate: 10,
    timeUnit: "5s",
    duration: "1m",
    gracefulStop: "5s",
    preAllocatedVUs: 15,
    maxVUs: 20, // double the max rate vu's
  },
  20: {
    executor: "constant-arrival-rate",
    rate: 20,
    timeUnit: "5s",
    duration: "20m",
    gracefulStop: "5s",
    preAllocatedVUs: 40,
    maxVUs: 40, // double the max rate vu's
  },
  30: {
    executor: "constant-arrival-rate",
    rate: 30,
    timeUnit: "10s",
    duration: "20m",
    gracefulStop: "5s",
    preAllocatedVUs: 60,
    maxVUs: 60, // double the max rate vu's
  },
  40: {
    executor: "constant-arrival-rate",
    rate: 40,
    timeUnit: "20s",
    duration: "20m",
    gracefulStop: "5s",
    preAllocatedVUs: 45,
    maxVUs: 95, // double the max rate vu's
  },
};

// @ts-ignore
let environment = __ENV.environment as Env;
// @ts-ignore
if (!environment) {
  environment = "staging";
}

// @ts-ignore
let rateConfig = __ENV.rateConfig as Rate;
// @ts-ignore
if (!rateConfig) {
  rateConfig = "1";
}

export const authoringLoginUrl = environments[environment].authoringLoginUrl;
export const subscriberLoginUrl = environments[environment].subscriberLoginUrl;
export const authoringApiUrl = environments[environment].authoringApiUrl;
export const subscriberApiUrl = environments[environment].subscriberApiUrl;
export const webhook = environments[environment].webhook;
export const authoringOrigin = environments[environment].authoringOrigin;
export const subscriberOrigin = environments[environment].subscriberOrigin;
export const referer = environments[environment].referer;
export const authoringLogin = environments[environment].authoringLogins;
export const subscriberLogin = environments[environment].subscriberLogins;
export const rateConfigValue = loadTestConfig[rateConfig];
