import { test, expect } from "@playwright/test";
import { user } from "../testdata/users";
import { env } from "../testdata/environments";
import { LoginPage } from "../pages/LoginPage";
import { TestHarnessPage } from "../pages/TestHarnessPage";
import { assert } from "console";

test.describe("tableEntry component tests", async () => {
  let testharnessPage: TestHarnessPage;

  test.beforeEach(async ({ page }) => {
    testharnessPage = await new TestHarnessPage(page);
    await testharnessPage.URLToTestharness();
    await page.setViewportSize({ width: 1920, height: 1080 });
  });

  test("[@regression] Select configuration", async ({ page, }) => {
    await testharnessPage.clickConfiguration();
  });

  test("[@sanity][@regression] Validate configurations available", async ({ page, }) => {
    await testharnessPage.clickConfiguration();
    await testharnessPage.validateConfigurationvalues();
  });

  test("[@regression] Validate columns when DES is selected", async ({ page, }) => {
    await testharnessPage.clickConfiguration();
    await testharnessPage.selectDES();
    await page.waitForTimeout(1000);
    await testharnessPage.validateColumnsForDes();
  });

  test("[@regression] Validate columns when FOB is selected", async ({ page, }) => {
    await testharnessPage.clickConfiguration();
    await testharnessPage.selectFOB();
    await page.waitForTimeout(1000);
    await testharnessPage.validateColumnsForFob();
  });

  test("[@regression] Validate title availaibility on selecting configuration FOB", async ({ page, }) => {
    await testharnessPage.clickConfiguration();
    await testharnessPage.selectFOB();
    await page.waitForTimeout(1000);
    await testharnessPage.validateTitle();
    await testharnessPage.validateTitlePlaceholder();
  });

  test(" [@regression] Validate title availaibility on selecting configuration DES", async ({ page, }) => {
    await testharnessPage.clickConfiguration();
    await testharnessPage.selectDES();
    await page.waitForTimeout(1000);
    await testharnessPage.validateTitle();
    await testharnessPage.validateTitlePlaceholder();
  });


  test("[@regression] Validate new row button availaibility on selecting configuration FOB", async ({ page, }) => {
    await testharnessPage.clickConfiguration();
    await testharnessPage.selectFOB();
    await page.waitForTimeout(1000);
    await testharnessPage.validateNewRowButton();
  });

  test(" [@regression] Validate new row button availaibility on selecting configuration DES", async ({ page, }) => {
    await testharnessPage.clickConfiguration();
    await testharnessPage.selectDES();
    await page.waitForTimeout(1000);
    await testharnessPage.validateNewRowButton();
  });

  test.skip("[@regression] Validate new row to be blank", async ({ page, }) => { //cannot be tested until data is clean
    await testharnessPage.clickConfiguration();
    await testharnessPage.selectFOB();
    await page.waitForTimeout(1000);
    await testharnessPage.clickNewRowButton();
    await testharnessPage.validateNewRowIsBlank();
  })

  test("[@regression] Verify initial status to be draft", async ({ page, }) => {
    await testharnessPage.clickConfiguration();
    await testharnessPage.selectFOB();
    await page.waitForTimeout(1000);
    await testharnessPage.clickNewRowButton();
    await page.waitForTimeout(1000);
    await testharnessPage.validateStatus();
  });

  test.skip("[@regression] Verify dates are blank", async ({ page, }) => { //cannot be tested until data is clean
    await testharnessPage.clickConfiguration();
    await testharnessPage.selectFOB();
    await page.waitForTimeout(1000);
    await testharnessPage.validateDatesAreBlank();
  });

  test("[@regression] Verify notes icon availability", async ({ page, }) => {
    await testharnessPage.clickConfiguration();
    await testharnessPage.selectFOB();
    await page.waitForTimeout(1000);
    await testharnessPage.validateNotesIcon();
  });

  test.skip("[@regression] Verify publish button availability", async ({ page, }) => {
    await testharnessPage.clickConfiguration();
    await testharnessPage.selectFOB();
    await page.waitForTimeout(3000);
    await testharnessPage.verifyPublishButton();
  });

  test("[@sanity] [@regression] Fill data in table for FOB", async ({ page, }) => {
    await testharnessPage.clickConfiguration();
    await testharnessPage.selectFOB();
    await page.waitForTimeout(1000);
    await testharnessPage.fillDataForFOB();
  });

  test("[@sanity][@regression] Verify saved data in table for FOB", async ({ page, }) => {
    await testharnessPage.clickConfiguration();
    await testharnessPage.selectFOB();
    await page.waitForTimeout(2000);
    await testharnessPage.validateDataForFOB();
  });

  test("[@sanity][@regression] Fill data in table for DES", async ({ page, }) => {
    await testharnessPage.clickConfiguration();
    await testharnessPage.selectDES();
    await page.waitForTimeout(1000);
    await testharnessPage.fillDataForDES();
  });

  test("[@sanity][@regression] Verify saved data in table for DES", async ({ page, }) => {
    await testharnessPage.clickConfiguration();
    await testharnessPage.selectDES();
    await page.waitForTimeout(2000);
    await testharnessPage.validateDataForDES();
  });

  test("[@regression] Verify saving notes in table for DES", async ({ page, }) => {
    await testharnessPage.clickConfiguration();
    await testharnessPage.selectDES();
    await page.waitForTimeout(1000);
    await testharnessPage.fillNotes();
    await testharnessPage.validateSavedNotes();
  });

  test.skip("Verify Publish button visibility for DES", async ({ page, }) => {
    await testharnessPage.clickConfiguration();
    await testharnessPage.selectDES();
    await page.waitForTimeout(1000);
    await testharnessPage.ValidatePublishBtn();
  });

  test.skip("Verify Draft and Publish Status for DES", async ({ page }) => {
    await testharnessPage.clickConfiguration();
    await testharnessPage.selectDES();
    await page.waitForTimeout(1000);
    await testharnessPage.ValidateDraftStatusForRow();
    await testharnessPage.publishRowData();
    await testharnessPage.ValidatePublishedStatusForRow();
  });

  test("[@regression] Verify saving notes in table for FOB", async ({ page, }) => {
    test.setTimeout(50000);
    await testharnessPage.clickConfiguration();
    await testharnessPage.selectFOB();
    await page.waitForTimeout(1000);
    await testharnessPage.fillNotes();
    await testharnessPage.validateSavedNotes();
  });

  test("[@regression] Verify submit button disabled in notes in table for FOB", async ({ page, }) => {
    test.setTimeout(50000);
    await testharnessPage.clickConfiguration();
    await testharnessPage.selectFOB();
    await page.waitForTimeout(1000);
    await testharnessPage.validateSubmitBtn();
  });

  test.skip("Verify Publish button visibility for FOB", async ({ page, }) => {
    await testharnessPage.clickConfiguration();
    await testharnessPage.selectFOB();
    await page.waitForTimeout(1000);
    await testharnessPage.ValidatePublishBtn();
  });

  test.skip("Verify Draft and Publish Status for FOB", async ({ page }) => {
    await testharnessPage.clickConfiguration();
    await testharnessPage.selectFOB();
    await page.waitForTimeout(1000);
    await testharnessPage.ValidateDraftStatusForRow();
    await testharnessPage.publishRowData();
    await testharnessPage.ValidatePublishedStatusForRow();
  });

  test("[@regression] Verify checkbox against each record in FOB", async ({ page, }) => {
    await testharnessPage.clickConfiguration();
    await testharnessPage.selectFOB();
    await page.waitForTimeout(1000);
    await testharnessPage.validateCheckbox();
  });

  test('[@regression] Checkbox should be unchecked by default', async ({ page, }) => {
    await testharnessPage.clickConfiguration();
    await testharnessPage.selectFOB();
    await page.waitForTimeout(1000);
    await testharnessPage.clickNewRowButton();
    await page.waitForTimeout(1000);
    await testharnessPage.isCheckboxUnCheckedLast();
  });

  test('[@regression] Verify text to select record when no checkbox is selected', async ({ page, }) => {
    await testharnessPage.clickConfiguration();
    await testharnessPage.selectFOB();
    await page.waitForTimeout(1000);
    await testharnessPage.verifyTextinWorkflowContainer();

  });

  test('[@regression] Verify checkbox against each record in DES', async ({ page, }) => {
    await testharnessPage.clickConfiguration();
    await testharnessPage.selectDES();
    await page.waitForTimeout(2000);
    await testharnessPage.validateCheckbox();
  });

  test("[@sanity][@regression] Verify checkbox get checked on clicking on the row", async ({ page, }) => {
    await testharnessPage.clickConfiguration();
    await testharnessPage.selectFOB();
    await page.waitForTimeout(1000);
    await testharnessPage.clickNewRowButton();
    await page.waitForTimeout(1000);
    await testharnessPage.clickCheckboxLast();
    await testharnessPage.isCheckboxCheckedLast();
  });


  test("[@sanity][@regression] Verify Publish Button when checkbox is selected", async ({ page, }) => {
    await testharnessPage.clickConfiguration();
    await testharnessPage.selectFOB();
    await page.waitForTimeout(1000);
    await testharnessPage.clickCheckbox();
    await testharnessPage.verifyWorkflowButton();
  });


  test("[@sanity][@regression] Verify workflow status when publish button is clicked for 1 row", async ({ page, }) => {
    await testharnessPage.clickConfiguration();
    await testharnessPage.selectFOB();
    await page.waitForTimeout(1000);
    await testharnessPage.clickNewRowButton();
    await page.waitForTimeout(1000);
    await testharnessPage.clickCheckboxLast();
    await testharnessPage.clickWorkflowButton();
    await page.waitForTimeout(1000);
    await testharnessPage.ValidatePublishedStatusForLastRow();
    await page.waitForTimeout(1000);
    await testharnessPage.isCheckboxUnCheckedLast();
  });

  test("[@regression] Verify Publish Button when multiple checkboxes are selected", async ({ page, }) => {
    await testharnessPage.clickConfiguration();
    await testharnessPage.selectFOB();
    await page.waitForTimeout(1000);
    await testharnessPage.addMultipleRows(6);
    await testharnessPage.selectMultipleCheckboxes(4);
    await testharnessPage.verifyWorkflowButton();
  });

  test("[@regression] Publish multiple rows and verify status", async ({ page, }) => {
    await testharnessPage.clickConfiguration();
    await testharnessPage.selectFOB();
    await page.waitForTimeout(1000);
    await testharnessPage.addMultipleRows(6);
    await testharnessPage.fillPriceforMultipleRows(); //for handling already published rows
    await testharnessPage.selectMultipleCheckboxes(4);
    await testharnessPage.clickWorkflowButton();
    await page.waitForTimeout(2000);
    await testharnessPage.verifyWorkflowStatusForMultipleRows(4);
  });

  test("[@regression] Verify published record moves to draft on editing", async ({ page, }) => {
    await testharnessPage.clickConfiguration();
    await testharnessPage.selectFOB();
    await page.waitForTimeout(1000);
    await testharnessPage.clickNewRowButton();
    await page.waitForTimeout(5000);
    await testharnessPage.clickCheckboxLast();
    await testharnessPage.clickWorkflowButton();
    await testharnessPage.ValidatePublishedStatusForLastRow();
    await page.waitForTimeout(500);
    await testharnessPage.fillPriceforLast();
    await testharnessPage.clickPriceHeader();
    await page.waitForTimeout(1000);
    await testharnessPage.ValidateDraftStatusForLastRow();
  });

});