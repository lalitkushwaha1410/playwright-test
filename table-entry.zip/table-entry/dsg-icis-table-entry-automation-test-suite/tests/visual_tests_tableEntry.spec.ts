import { test, expect, chromium } from "@playwright/test";
import { LoginPage } from "../pages/LoginPage";
import { TestHarnessPage } from "../pages/TestHarnessPage";

test.describe("tableEntry visual regression tests for content", async () => {
  let testharnessPage: TestHarnessPage;
  let loginPage: LoginPage;
  const SnapDir = './tests/visual_tests_content.spec.ts-snapshots/';

  test.beforeEach(async ({ page }) => {
    testharnessPage = await new TestHarnessPage(page);
    await testharnessPage.URLToTestharness();
  });

});