import { test, expect } from "@playwright/test";
import { user } from "../testdata/users";
import { env } from "../testdata/environments";
import { LoginPage } from "../pages/LoginPage";
import { AuthoringPage } from "../pages/AuthoringPage";
import { TableData } from "../testdata/tableData";

test.describe("tableEntry E2E tests", async () => {
    let authoringPage: AuthoringPage;
    let loginPage: LoginPage;

    test.beforeEach(async ({ page }) => {
        authoringPage = await new AuthoringPage(page);
        await authoringPage.LoginToE2E();
    });

    test("Fill data in table for FOB", async ({ page, }) => {
        test.setTimeout(50000);
        await authoringPage.createNewPage();
        await authoringPage.add_Content();
        await page.waitForTimeout(1000);
        await authoringPage.clickConfiguration();
        await authoringPage.validateConfigurationvalues();
        await authoringPage.selectFOB();
        await page.waitForTimeout(1000);
        await authoringPage.validateNotesIcon();
        await authoringPage.validateNewRowButton();
        await authoringPage.ValidatePublishBtn();
        await authoringPage.fillDataForFOB();
        await authoringPage.deleteNewPage();
    });
    test("Fill data in table for DES", async ({ page, }) => {
        test.setTimeout(50000);
        await authoringPage.createNewPage();
        await authoringPage.add_Content();
        await page.waitForTimeout(1000);
        await authoringPage.clickConfiguration();
        await authoringPage.validateConfigurationvalues();
        await authoringPage.selectDES();
        await page.waitForTimeout(1000);
        await authoringPage.validateNotesIcon();
        await authoringPage.validateNewRowButton();
        await authoringPage.ValidatePublishBtn();
        await authoringPage.fillDataForDES();
        await authoringPage.deleteNewPage();
    });
});
