#!/bin/bash
# Install dependencies and execute tests
yarn install && \
yarn add -D @playwright/test && \
yarn add -D cross-env && \
yarn add -D playwright@latest

CLASSNAME=${CLASSNAME:-$1}

if [ "$CLASSNAME" == "comp-tableEntry" ]; then
  yarn test:comp-tableEntry
elif [ "$CLASSNAME" == "visual-tableEntry" ]; then
  yarn test:visual-tableEntry
elif [ "$CLASSNAME" == "comp-sanity" ]; then
  yarn test:sanity
elif [ "$CLASSNAME" == "e2e" ]; then
  yarn test:e2e
elif [ "$CLASSNAME" == "all" ]; then
  yarn test:all
else
  echo "Unknown CLASSNAME: $CLASSNAME"
  exit 1
fi