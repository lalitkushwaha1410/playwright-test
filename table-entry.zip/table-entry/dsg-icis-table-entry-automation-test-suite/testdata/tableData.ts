// Generate dynamic dates using the current month
const getCurrentMonthInfo = () => {
  const currentDate = new Date();
  const currentMonth = currentDate.toLocaleString('en-US', { month: 'short' });
  const currentYear = currentDate.getFullYear() + 2; // Use 2 years in the future for test data
  const daysInMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0).getDate();

  return {
    monthShort: currentMonth,
    year: currentYear,
    daysInMonth: daysInMonth
  };
};

const monthInfo = getCurrentMonthInfo();

export const TableData = {
  data: [
    {
      Buyer: 'APLNG',
      Seller: 'BP',
      Price: '345.6',
      Vessel: 'Arctica',
      LoadPort: 'Asia',
      Origin: 'Argentina',
      Destination: 'Australia',
      DeliveryPeriodFrom: '2',
      DeliveryPeriodTo: '15',
      TransactionDate: '15',
      LiftingPeriodFrom: '2',
      LiftingPeriodTo: '15',
      FullTransactionDate: `15 ${monthInfo.monthShort} 2025`,
      FullLiftingPeriodFrom: `02 ${monthInfo.monthShort} 2025`,
      FullLiftingPeriodTo: `15 ${monthInfo.monthShort} 2025`,
      FullDeliveryPeriodFrom: `02 ${monthInfo.monthShort} 2025`,
      FullDeliveryPeriodTo: `15 ${monthInfo.monthShort} 2025`,
    }
  ],
};
