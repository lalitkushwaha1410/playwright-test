import { test, expect, Locator, Page } from "@playwright/test";
import { user } from "../testdata/users";
import { env, getEnv, getBrowser } from "../testdata/environments";
import { LoginPage } from "../pages/LoginPage";
import { TableData } from "../testdata/tableData";
import { read } from "fs";
import { randomInt } from "crypto";

let loginPage: LoginPage;


export class TestHarnessPage {
  readonly page: Page;
  readonly configurationBtn: Locator;
  readonly radioBtn: Locator;
  readonly gridColumns: Locator;
  readonly gridSelector: Locator;
  readonly saveBtn: Locator;
  readonly title: Locator;
  readonly newRow: Locator;
  readonly inputBox: Locator;
  readonly status: Locator;
  readonly dateSelector: Locator;
  readonly notesIcon: Locator;
  readonly publish: Locator;
  readonly buyer: Locator;
  readonly seller: Locator;
  readonly price: Locator;
  readonly vessel: Locator;
  readonly loadPort: Locator;
  readonly transactionDate: Locator;
  readonly selectDate: Locator;
  readonly priceHeader: Locator;
  readonly origin: Locator;
  readonly destination: Locator;
  readonly buyer_input: Locator;
  readonly seller_input: Locator;
  readonly price_input: Locator;
  readonly vessel_input: Locator;
  readonly loadPort_input: Locator;
  readonly origin_input: Locator;
  readonly destination_input: Locator;
  readonly notesTextArea: Locator;
  readonly savedNotes: Locator;
  readonly publishBtn: Locator;
  readonly rowStatus: Locator;
  readonly clickPublishInPopup: Locator;
  readonly selectDESTrade: Locator;
  readonly selectFOBTrade: Locator;
  readonly submitButton: Locator;
  readonly notesPopupClose: Locator;
  readonly checkboxInput: Locator;
  readonly workflowContainer: Locator;
  readonly workflowButton: Locator;
  readonly workflowCloseBtn: Locator;
  readonly selectdropdown: Locator;
  readonly freeClick: Locator;
  readonly priceCol: Locator;
  readonly price_input_rows: Locator;
  readonly gridCell: Locator;


  constructor(page: Page) {
    this.page = page;
    this.configurationBtn = page.locator('button[data-testid="table-entry-selection-card-add-button"]');
    this.radioBtn = page.locator('label');
    this.saveBtn = page.getByTestId("saveBtn");
    this.gridSelector = page.getByTestId("table-entry-grid-container");
    this.gridColumns = page.locator('div[class="ag-header-cell-comp-wrapper"]');
    this.title = page.getByTestId("table-entry-content-block-wrapper-header");
    this.newRow = page.getByTestId("add-new-row");
    this.inputBox = page.getByTestId("text-box");
    this.priceHeader = page.locator('div[role="columnheader"][col-id="price"]');
    this.status = page.locator('div[role="gridcell"][col-id="status"]');
    this.dateSelector = page.locator('span[data-testid="date-wrapper"]');
    this.notesIcon = page.locator('svg[data-testid="comments-icon"]');
    this.publish = page.getByTestId("Publish");
    this.buyer = page.locator(".cell-0-buyer");
    this.selectdropdown = page.locator("div[id*='listbox']");
    this.seller = page.locator(".cell-0-seller");
    this.price = page.locator(".cell-0-price");
    this.priceCol = page.locator("div[col-id='price']");
    this.price_input = page.locator("div[role='rowgroup'] .ag-row-first div[col-id='price'] div input");
    this.price_input_rows = page.locator("div[col-id='price'] div input");
    this.vessel = page.locator(".cell-0-vessel");
    this.loadPort = page.locator(".cell-0-load_port");
    this.transactionDate = page.locator('div[role="gridcell"][col-id="transaction_date"]>div');
    this.origin = page.locator(".cell-0-origin");
    this.destination = page.locator(".cell-0-destination");
    //this.destination_input = page.locator("div[role='rowgroup'] .ag-row-first div[col-id='destination'] div input");
    this.selectDate = page.locator('button[role="gridcell"][type="button"]');
    this.notesTextArea = page.locator('textarea[placeholder="Enter internal note"]');
    this.notesPopupClose = page.locator('svg[data-icon="xmark"]');
    this.savedNotes = page.locator('svg[data-testid="numbered-comments-icon"]');
    this.publishBtn = page.locator('div[data-testid="grid-workflow-container"] button[data-testid="Publish"]');
    this.rowStatus = page.locator('span[data-testid="table-entry-item-status"] span span');
    this.clickPublishInPopup = page.locator('button[data-testid="modal-footer-workflow-action-btn"]');
    this.selectDESTrade = page.getByText('Test LNG Global DES Trades');
    this.selectFOBTrade = page.getByText('Test LNG Global FOB Trades');
    this.submitButton = page.getByText('Submit');
    this.checkboxInput = page.locator('div[role="gridcell"][col-id="checkbox"] input[type="checkbox"]');
    this.workflowContainer = page.locator('div[data-testid="grid-workflow-container"]');
    this.gridCell = this.page.locator("div[role='gridcell']");
    this.workflowButton = this.workflowContainer.locator('div[data-testid="button-container"]');
    this.workflowCloseBtn = page.locator('div[data-testid="workflow-success-modal"] button[data-testid="closeBtn"]');
    this.freeClick = page.locator('div[data-testid="table-entry-content-block-wrapper-edit-button-container"]');
  }

  async URLToTestharness() {
    await this.page.goto(getEnv().TestHarnessUrl);
  }

  async LoginToTestharness(username, password) {
    loginPage = await new LoginPage(this.page);
    await loginPage.logintotestharness(username, password, getEnv().TestHarnessUrl);
  }

  async clickConfiguration() {
    await this.configurationBtn.click();
  }

  async validateConfigurationvalues() {
    const DES = await this.selectDESTrade.textContent();
    const FOB = await this.selectFOBTrade.textContent();
    expect(DES).toEqual("Test LNG Global DES Trades");
    expect(FOB).toEqual("Test LNG Global FOB Trades");
  }

  async selectDES() {
    await this.selectDESTrade.click();
    await this.saveBtn.click();
  }

  async selectFOB() {
    await this.selectFOBTrade.click();
    await this.saveBtn.click();
  }

  async validateColumnsForDes() {
    const texts = await this.gridColumns.allInnerTexts();
    const filteredTexts = texts.map(text => text.trim()).filter(text => text !== '');
    console.log("Columns for des are  :", filteredTexts);
    const expectedColumns = [
      "Buyer", "Seller", "Transaction date", "Delivery Period",
      "Price", "Vessel", "Origin", "Destination", "Status", "Last Updated on", "Notes"
    ];
    expect(filteredTexts).toEqual(expectedColumns);
  }

  async validateColumnsForFob() {
    const texts = await this.gridColumns.allInnerTexts();
    const filteredTexts = texts.map(text => text.trim()).filter(text => text !== '');
    console.log("Columns for fob are:", filteredTexts);
    const expectedColumns = [
      "Buyer", "Seller", "Transaction date", "Lifting Period",
      "Price", "Vessel", "Load Port", "Status", "Last Updated on", "Notes"
    ];
    expect(filteredTexts).toEqual(expectedColumns);
  }

  async validateTitle() {
    const titlevisibility = await this.title.isVisible();
    expect(titlevisibility).toBe(true);
  }

  async validateTitlePlaceholder() {
    const titleplaceholdervisibility = await this.title.getByPlaceholder("Enter title").isVisible();
    expect(titleplaceholdervisibility).toBe(true);
  }

  async validateNewRowButton() {
    const newRowVisibility = await this.newRow.isVisible();
    expect(newRowVisibility).toBe(true);
  }

  async validateNewRowIsBlank() {
    const textboxdata = (await this.gridCell.locator("div[data-testid='text-box']").last().textContent()).trim();
    expect(textboxdata).toBe('');
    const sellerdata = (await this.seller.last().textContent()).trim();
    expect(sellerdata).toBe('Select seller');
    const buyerdata = (await this.buyer.last().textContent()).trim();
    expect(buyerdata).toBe('Select buyer');
    const vesseldata = (await this.vessel.last().textContent()).trim();
    expect(vesseldata).toBe('Select vessel');
    const loadportdata = (await this.loadPort.last().textContent()).trim();
    expect(loadportdata).toBe('Select load port');
    const liftingperiodfromdata = (await this.dateSelector.nth(1).last().textContent()).trim();
    expect(liftingperiodfromdata).toContain('DD MMM YYYY');
    const liftingperiodtodata = (await this.dateSelector.nth(2).last().textContent()).trim();
    expect(liftingperiodtodata).toContain('DD MMM YYYY');
    const transactiondatedata = (await this.transactionDate.last().textContent()).trim();
    expect(transactiondatedata).toContain('DD MMM YYYY');
  };

  async validateDatesAreBlank() {
    const cellDate = await this.dateSelector.evaluateAll(elements =>
      elements.map(element => element.textContent?.trim() || '')
    );
    cellDate.forEach(text => {
      expect(text).toBe('DD MMM YYYY');
    });
  }

  async clickNewRowButton() {
    await this.newRow.click();
  }

  async addMultipleRows(n) {
    // Count how many checkboxes are present
    const count = await this.checkboxInput.count();
   // console.log(`Found ${count} checkboxes in the table`);

    // Add rows only if we need more
    if (n > count) {
    //  console.log(`Adding ${n - count} more rows to reach target of ${n} rows`);
      for (let i = 0; i < n - count; i++) {
        await this.newRow.click();
        await this.page.waitForTimeout(500); // Add short delay between clicks
      }
     // console.log(`Now have ${n} rows in the table`);
    } else {
      //console.log(`Already have ${count} rows which is >= ${n}, no need to add more rows`);
    }

    // Return the final row count
    const finalCount = await this.checkboxInput.count();
    return finalCount;
  }

  async validateStatus() {
    const initialstatus = await this.status.last().textContent();
    expect(initialstatus).toEqual("DRAFT");
  }

  async validateNotesIcon() {
    const notesIconVisibility = await this.notesIcon.first().isVisible();
    expect(notesIconVisibility).toBe(true);
  }

  async verifyPublishButton() {
    const publishBtnVisibility = await this.publish.isVisible();
    expect(publishBtnVisibility).toBe(true);
  }

  async fillBuyer() {

    await this.buyer.click();
    await this.page.waitForTimeout(1000);
    const selectBuyer = this.selectdropdown.getByText(TableData.data[0].Buyer, { exact: true });
    const isChecked = await selectBuyer.getAttribute('aria-selected');

    if (isChecked === 'true') {
      console.log("Buyer checkbox is already selected. Moving ahead...");
    } else {
      console.log("Buyer checkbox is not selected. Selecting it now...");
      await selectBuyer.click();
    }
    await this.page.waitForTimeout(1000);
    await this.buyer.click();
    //await this.page.waitForTimeout(1000);
    // await this.freeClick.click();
    // await this.buyer_input.fill(TableData.data[0].Buyer);
    // await this.selectdropdown.click();

  }

  async fillSeller() {
    await this.seller.click();
    await this.page.waitForTimeout(1000);
    const selectSeller = this.selectdropdown.getByText(TableData.data[0].Seller, { exact: true });
    const isChecked = await selectSeller.getAttribute('aria-selected');

    if (isChecked === 'true') {
      console.log("Seller checkbox is already selected. Moving ahead...");
    } else {
      console.log("Seller checkbox is not selected. Selecting it now...");
      await selectSeller.click();
    }
    await this.page.waitForTimeout(1000);
    await this.seller.click();
  }

  async fillPrice() {
    await this.price.click();
    await this.price_input.fill(TableData.data[0].Price);
    await this.page.waitForTimeout(500);
  }

  async fillPriceforLast() {
    await this.priceCol.last().click();
    await this.price_input_rows.last().fill("488.8");
    await this.page.waitForTimeout(500);
  }

  async fillPriceforMultipleRows() {
    // Fill price value 200 for first 4 rows
    for (let i = 1; i < 5; i++) {
    //  console.log(`Filling price for row ${i}`);
      // Click on the price cell for the current row
      const priceCell = this.priceCol.nth(i);
      await priceCell.click();
      await this.price_input_rows.nth(1).fill(randomInt(100, 500).toString());

      // Add a small delay between rows
      await this.page.waitForTimeout(500);
    }

    console.log("Successfully filled price for first 4 rows");
  }

  async clickStatus() {

  }

  async fillVessel() {
    await this.vessel.click();
    await this.page.waitForTimeout(1000);
    const selectVessel = this.selectdropdown.getByText(TableData.data[0].Vessel, { exact: true });
    const isChecked = await selectVessel.getAttribute('aria-selected');
    if (isChecked === 'true') {
      console.log("Vessel checkbox is already selected. Moving ahead...");
    } else {
      console.log("Vessel checkbox is not selected. Selecting it now...");
      await selectVessel.click();
    }
    await this.page.waitForTimeout(1000);
    await this.vessel.click();
  }

  async fillOrigin() {
    await this.origin.click();
    await this.page.waitForTimeout(1000);
    const selectOrigin = this.selectdropdown.getByText(TableData.data[0].Origin, { exact: true });
    const isChecked = await selectOrigin.getAttribute('aria-selected');

    if (isChecked === 'true') {
      console.log("Origin checkbox is already selected. Moving ahead...");
    } else {
      console.log("Origin checkbox is not selected. Selecting it now...");
      await selectOrigin.click();
    }
    await this.page.waitForTimeout(1000);
    await this.origin.click();
  }

  async fillLoadPort() {
    await this.loadPort.click();
    await this.page.waitForTimeout(1000);
    const selectLoadPort = this.selectdropdown.getByText(TableData.data[0].LoadPort, { exact: true });
    const isChecked = await selectLoadPort.getAttribute('aria-selected');

    if (isChecked === 'true') {
      console.log("LoadPort checkbox is already selected. Moving ahead...");
    } else {
      console.log("LoadPort checkbox is not selected. Selecting it now...");
      await selectLoadPort.click();
    }
    await this.page.waitForTimeout(1000);
    await this.loadPort.click();
  }

  async fillTransactionDate() {
    await this.dateSelector.nth(0).waitFor();
    await this.dateSelector.nth(0).click();
    const selectTransactionDate = this.selectDate.getByText(TableData.data[0].TransactionDate, { exact: true });
    await selectTransactionDate.waitFor();
    await selectTransactionDate.click();
  }

  async fillLiftingPeriodRange() {
    // Check if a date is already selected for Lifting Period
    const firstDateText = await this.dateSelector.nth(1).textContent();
    const secondDateText = await this.dateSelector.nth(2).textContent();
    
    // If dates are already selected (not showing the default 'DD MMM YYYY')
    if (firstDateText !== 'DD MMM YYYY' || secondDateText !== 'DD MMM YYYY') {
      console.log('Dates already selected. Skipping date selection.');
      return; // Skip the date selection process if dates are already selected
    }
    
    // Proceed with selecting dates only if they're not already selected
    await this.dateSelector.nth(1).waitFor();
    await this.dateSelector.nth(1).click();
    await this.selectDate.getByText(TableData.data[0].LiftingPeriodFrom, { exact: true }).first().click();
    await this.selectDate.getByText(TableData.data[0].LiftingPeriodTo, { exact: true }).first().click();
  }

  async fillDeliveryPeriodRange() {
     // Check if a date is already selected for Delivery Period
     const firstDateText = await this.dateSelector.nth(1).textContent();
     const secondDateText = await this.dateSelector.nth(2).textContent();
     
     // If dates are already selected (not showing the default 'DD MMM YYYY')
     if (firstDateText !== 'DD MMM YYYY' || secondDateText !== 'DD MMM YYYY') {
       console.log('Dates already selected. Skipping date selection.');
       return; // Skip the date selection process if dates are already selected
     }
     
     // Proceed with selecting dates only if they're not already selected
    await this.dateSelector.nth(1).waitFor();
    await this.dateSelector.nth(1).click();
    await this.selectDate.getByText(TableData.data[0].DeliveryPeriodFrom, { exact: true }).first().click();
    await this.selectDate.getByText(TableData.data[0].DeliveryPeriodTo, { exact: true }).first().click();
  }

  async clickPriceHeader() {
    await this.priceHeader.click();
  }

  async fillDestination() {
    await this.destination.click();
    await this.page.waitForTimeout(1000);
    const selectDestination = this.selectdropdown.getByText(TableData.data[0].Destination, { exact: true });
    const isChecked = await selectDestination.getAttribute('aria-selected');

    if (isChecked === 'true') {
      console.log("LoadPort checkbox is already selected. Moving ahead...");
    } else {
      console.log("LoadPort checkbox is not selected. Selecting it now...");
      await selectDestination.click();
    }
    await this.page.waitForTimeout(1000);
    await this.destination.click();
  }


  async fillDataForFOB() {
    await this.fillBuyer();
    await this.fillSeller();
    await this.fillPrice();
    await this.fillVessel();
    await this.fillLoadPort();
    await this.fillTransactionDate();
    await this.fillLiftingPeriodRange();
    await this.clickPriceHeader();
  }

  async fillDataForDES() {
    await this.fillBuyer();
    await this.fillSeller();
    await this.fillPrice();
    await this.fillVessel();
    await this.fillOrigin();
    await this.fillDestination();
    await this.fillTransactionDate();
    await this.fillDeliveryPeriodRange();
    await this.clickPriceHeader();
  }

  async validateDataForFOB() {
    const buyerText = await this.buyer.textContent();
    const sellerText = await this.seller.textContent();
    const priceText = await this.price.textContent();
    const vesselText = await this.vessel.textContent();
    const loadPortText = await this.loadPort.textContent();
    const transactionDateText = await this.transactionDate.first().textContent();
    const liftingPeriodFromText = await this.dateSelector.nth(1).first().textContent();
    const liftingPeriodToText = await this.dateSelector.nth(2).first().textContent();
    expect(buyerText).toEqual(TableData.data[0].Buyer);
    expect(sellerText).toEqual(TableData.data[0].Seller);
    expect(priceText).toEqual(TableData.data[0].Price);
    expect(vesselText).toEqual(TableData.data[0].Vessel);
    expect(loadPortText).toEqual(TableData.data[0].LoadPort);
    expect(transactionDateText).toEqual(TableData.data[0].FullTransactionDate);
    expect(liftingPeriodFromText).toEqual(TableData.data[0].FullLiftingPeriodFrom);
    expect(liftingPeriodToText).toEqual(TableData.data[0].FullLiftingPeriodTo);
  }

  async validateDataForDES() {
    const buyerText = await this.buyer.textContent();
    const sellerText = await this.seller.textContent();
    const priceText = await this.price.textContent();
    const vesselText = await this.vessel.textContent();
    const originText = await this.origin.textContent();
    const destinationText = await this.destination.textContent();
    const transactionDateText = await this.transactionDate.first().textContent();
    const FullDeliveryPeriodFromText = await this.dateSelector.nth(1).textContent();
    const FullDeliveryPeriodToText = await this.dateSelector.nth(2).textContent();
    expect(buyerText).toEqual(TableData.data[0].Buyer);
    expect(sellerText).toEqual(TableData.data[0].Seller);
    expect(priceText).toEqual(TableData.data[0].Price);
    expect(vesselText).toEqual(TableData.data[0].Vessel);
    expect(originText).toEqual(TableData.data[0].Origin);
    expect(destinationText).toEqual(TableData.data[0].Destination);
    expect(transactionDateText).toEqual(TableData.data[0].FullTransactionDate);
    expect(FullDeliveryPeriodFromText).toEqual(TableData.data[0].FullDeliveryPeriodFrom);
    expect(FullDeliveryPeriodToText).toEqual(TableData.data[0].FullDeliveryPeriodTo);
  }

  async fillNotes() {

    await this.page.waitForTimeout(2000);
    if (await this.savedNotes.first().count() > 0) {
      await this.savedNotes.first().click();
    }
    else if (await this.notesIcon.first().count() > 0) {
      await this.notesIcon.first().click();
    }
    else {
      throw new Error("Neither comments-icon nor numbered-comments-icon found");
    }
    await this.page.waitForTimeout(1000);
    await this.notesTextArea.clear();
    await this.page.waitForTimeout(1000);
    await this.notesTextArea.fill("Sample Notes from Auto");
    await this.page.waitForTimeout(1000);
    await this.submitButton.click();
    await this.page.waitForTimeout(1000);
  }

  async validateSubmitBtn() {
    await this.page.waitForTimeout(2000);
    if (await this.savedNotes.first().count() > 0) {
      await this.savedNotes.first().click();
    }
    else if (await this.notesIcon.first().count() > 0) {
      await this.notesIcon.first().click();
    }
    else {
      throw new Error("Neither comments-icon nor numbered-comments-icon found");
    }
    await this.page.waitForTimeout(2000);
    await this.notesTextArea.clear();
    await this.page.waitForTimeout(2000);
    const submitButtonState = await this.submitButton.isDisabled();
    expect(submitButtonState).toBe(true);
  }

  async validateSavedNotes() {
    await this.savedNotes.first().click();
    const savedNotes = await this.notesTextArea.textContent();
    expect(savedNotes).toEqual("Sample Notes from Auto");
  }

  async ValidatePublishBtn() {
    const publishBtnVisiility = await this.publishBtn.isEnabled();
    expect(publishBtnVisiility).toBeTruthy();
  }

  async ValidateDraftStatusForRow() {
    const draftStatus = await this.rowStatus.textContent();
    expect(draftStatus).toEqual("DRAFT");
  }

  async ValidatePublishedStatusForRow() {
    const publishedStatus = await this.rowStatus.textContent();
    expect(publishedStatus).toEqual("PUBLISHED");
  }

  async ValidatePublishedStatusForLastRow() {
    const lastRowStatus = await this.page.locator('div[role="gridcell"][col-id="status"] span span span').last().textContent();
    // console.log(`Status of lastrecord is: ${lastRowStatus} and should be published`);
    expect(lastRowStatus).toEqual("PUBLISHED");
  }

  async ValidateDraftStatusForLastRow() {
    const lastStatus = await this.rowStatus.last().textContent();
    // console.log(`status of last record is: ${lastStatus} and should be draft`);
    expect(lastStatus).toEqual("DRAFT");
  }

  async publishRowData() {
    await this.publishBtn.click();
    await this.page.waitForTimeout(1000);
    await this.clickPublishInPopup.click();
    await this.page.waitForTimeout(2000);
  }

  async isCheckboxUnChecked() {
    // Find the checkbox and return its checked state
    const ariaLabel = await this.checkboxInput.getAttribute('aria-label');
    expect(ariaLabel).toBe('Press Space to toggle row selection (unchecked)');
  }

  async isCheckboxUnCheckedLast() {
    // Find the checkbox and return its checked state
    const ariaLabel = await this.checkboxInput.last().getAttribute('aria-label');
    expect(ariaLabel).toBe('Press Space to toggle row selection (unchecked)');
  }

  async isCheckboxChecked() {
    // Find the checkbox and return its checked state
    const ariaLabel = await this.checkboxInput.getAttribute('aria-label');
    expect(ariaLabel).toBe('Press Space to toggle row selection (checked)');
  }

  async isCheckboxCheckedLast() {
    // Find the checkbox and return its checked state
    const ariaLabel = await this.checkboxInput.last().getAttribute('aria-label');
    expect(ariaLabel).toBe('Press Space to toggle row selection (checked)');
  }

  async validateCheckbox() {
    const checkBoxVisibility = await this.checkboxInput.first().isVisible();
    expect(checkBoxVisibility).toBe(true);
  }

  async clickCheckbox() {
    await this.checkboxInput.first().click();
  };

  async clickCheckboxLast() {
    // this.page.waitForLoadState('networkidle');
    await this.checkboxInput.last().click();
  };

  async selectMultipleCheckboxes(count: number) {
    // Count how many checkboxes are present
    for (let i = 0; i < count; i++) {
     // console.log(`Clicking checkbox ${i + 1}`);
      await this.checkboxInput.nth(i).click();
      await this.page.waitForTimeout(500); // Small wait between clicks
    }
  }

  async verifyTextinWorkflowContainer() {
    const workflowContainerText = await this.workflowContainer.first().textContent();
    expect(workflowContainerText).toEqual("Please select a record to continue");
  };

  async verifyWorkflowButton() {
    await this.publishBtn.first().waitFor();
    const publishBtn = await this.publishBtn.first().isVisible();
    //this.page.waitForTimeout(3000);
    expect(publishBtn).toBe(true);
  };

  async clickWorkflowButton() {
    await this.publishBtn.first().waitFor();
    // await this.publishBtn.first().scrollIntoViewIfNeeded();
    await this.publishBtn.first().click();
    // await this.clickPublishInPopup.waitFor();
    await this.page.waitForTimeout(3000);
    await this.clickPublishInPopup.click();
    //  await this.page.waitForTimeout(2000);
    //await this.workflowCloseBtn.waitFor();
  };

  async verifyWorkflowStatusForMultipleRows(expectedPublishedCount) {
    // Get all status elements
    const count = await this.rowStatus.count();
   // console.log(`Found ${count} status elements in the table`);

    // Track how many rows are published
    let publishedCount = 0;

    // Check each row's status
    for (let i = 0; i < count; i++) {
      const eachrowstatus = await this.page.locator('div[role="gridcell"][col-id="status"] span span span').nth(i).textContent();
     // console.log(`Row ${i} status: ${eachrowstatus}`);

      if (eachrowstatus === "PUBLISHED") {
        publishedCount++;
      }
    }

    console.log(`Found ${publishedCount} rows with PUBLISHED status`);

    // Assert that the number of published rows matches the expected count
    expect(publishedCount).toBeGreaterThanOrEqual(expectedPublishedCount);
  };
};