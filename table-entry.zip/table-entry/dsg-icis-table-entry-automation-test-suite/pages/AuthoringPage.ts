import { test, expect, Locator, Page } from "@playwright/test";
import { user } from "../testdata/users";
import { env, getEnv, getBrowser } from "../testdata/environments";
import { LoginPage } from "../pages/LoginPage";
import { TableData } from "../testdata/tableData";
import { read } from "fs";

let loginPage: LoginPage;


export class AuthoringPage {

    readonly page: Page;
    readonly createNew: Locator;
    readonly headLine: Locator;
    readonly pageDescription: Locator;
    readonly nextbtn: Locator;
    readonly onecolumnTemplate: Locator;
    readonly createPageBtn: Locator;
    readonly pageTitle: Locator;
    readonly addContentBlock: Locator;
    readonly clickTableEntryCard: Locator;
    public page_title: string;
    public pageTitleLink: Locator;
    public deleteButton: Locator;
    readonly deleteIcon: Locator;
    readonly pricingIcon: Locator;
    readonly configurationBtn: Locator;
    readonly radioBtn: Locator;
    readonly gridColumns: Locator;
    readonly gridSelector: Locator;
    readonly saveBtn: Locator;
    readonly title: Locator;
    readonly newRow: Locator;
    readonly inputBox: Locator;
    readonly status: Locator;
    readonly dateSelector: Locator;
    readonly notesIcon: Locator;
    readonly publish: Locator;
    readonly dataSupplier: Locator;
    readonly buyer: Locator;
    readonly seller: Locator;
    readonly price: Locator;
    readonly vessel: Locator;
    readonly loadPort: Locator;
    readonly transactionDate: Locator;
    readonly selectDate: Locator;
    readonly priceHeader: Locator;
    readonly origin: Locator;
    readonly destination: Locator;
    readonly dataSupplier_input: Locator;
    readonly buyer_input: Locator;
    readonly seller_input: Locator;
    readonly price_input: Locator;
    readonly vessel_input: Locator;
    readonly loadPort_input: Locator;
    readonly origin_input: Locator;
    readonly destination_input: Locator;
    readonly notesTextArea: Locator;
    readonly notesPopupClose: Locator;
    readonly savedNotes: Locator;
    readonly publishBtn: Locator;
    readonly rowStatus: Locator;
    readonly clickPublishInPopup: Locator;
    readonly selectDESTrade: Locator;
    readonly selectFOBTrade: Locator;


    constructor(page: Page) {
        this.page = page;
        this.createNew = page.getByTestId("create-new-page-button");
        this.headLine = page.getByTestId("headline-textarea");
        this.pageDescription = page.getByTestId("description-textarea");
        this.nextbtn = page.getByTestId("next-button");
        this.onecolumnTemplate = page.getByTestId("template-image-wrapper-One Column");
        this.createPageBtn = page.getByTestId("create-page-button");
        this.pageTitle = page.getByTestId("page-title");
        this.addContentBlock = page.locator('svg[aria-hidden="true"][data-icon="plus"]').first();
        this.clickTableEntryCard = page.getByTestId("content-block-button-table-entry-capability");
        this.deleteIcon = page.locator("svg[data-icon='trash-can']");
        this.pageTitleLink = page.getByTestId("page-title-link");
        this.deleteButton = page.getByTestId("modal-footer-delete-btn");
        this.pricingIcon = page.locator('svg[data-icon="square-dollar"]');
        this.configurationBtn = page.locator('button[data-testid="table-entry-selection-card-add-button"]');
        this.radioBtn = page.locator('label');
        this.saveBtn = page.getByTestId("saveBtn");
        this.gridSelector = page.getByTestId("table-entry-grid-container");
        this.gridColumns = page.locator('div[class="ag-header-cell-comp-wrapper"]');
        this.title = page.getByTestId("table-entry-content-block-wrapper-header");
        this.newRow = page.getByTestId("add-new-row");
        this.inputBox = page.getByTestId("text-box");
        this.priceHeader = page.locator('div[role="columnheader"][col-id="price"]');
        this.status = page.locator('div[role="gridcell"][col-id="status"]');
        this.dateSelector = page.locator('span[data-testid="date-wrapper"]');
        this.notesIcon = page.locator('svg[data-testid="comments-icon"]');
        this.publish = page.getByTestId("Publish");
        this.dataSupplier = page.locator(".cell-0-data_supplier");
        this.dataSupplier_input = page.locator("div[role='rowgroup'] .ag-row-first div[col-id='data_supplier'] div input");
        this.buyer = page.locator(".cell-0-buyer");
        this.buyer_input = page.locator("div[role='rowgroup'] .ag-row-first div[col-id='buyer'] div input");
        this.seller = page.locator(".cell-0-seller");
        this.seller_input = page.locator("div[role='rowgroup'] .ag-row-first div[col-id='seller'] div input");
        this.price = page.locator(".cell-0-price");
        this.price_input = page.locator("div[role='rowgroup'] .ag-row-first div[col-id='price'] div input");
        this.vessel = page.locator(".cell-0-vessel");
        this.vessel_input = page.locator("div[role='rowgroup'] .ag-row-first div[col-id='vessel'] div input");
        this.loadPort = page.locator(".cell-0-load_port");
        this.loadPort_input = page.locator("div[role='rowgroup'] .ag-row-first div[col-id='load_port'] div input");
        this.transactionDate = page.locator('div[role="gridcell"][col-id="transaction_date"]>div');
        this.origin = page.locator(".cell-0-origin");
        this.origin_input = page.locator("div[role='rowgroup'] .ag-row-first div[col-id='origin'] div input");
        this.destination = page.locator(".cell-0-destination");
        this.destination_input = page.locator("div[role='rowgroup'] .ag-row-first div[col-id='destination'] div input");
        this.selectDate = page.locator('button[role="gridcell"][type="button"]');
        this.notesTextArea = page.locator('textarea[placeholder="Enter internal note"]');
        this.notesPopupClose = page.locator('svg[data-icon="xmark"]');
        this.savedNotes = page.locator('svg[data-testid="numbered-comments-icon"]');
        this.publishBtn = page.locator('div[data-testid="button-container"]');
        this.rowStatus = page.locator('span[data-testid="table-entry-item-status"] span span');
        this.clickPublishInPopup = page.locator('button[data-testid="modal-footer-workflow-action-btn"]');
        this.selectDESTrade = page.getByText('LNG Global DES Trades');
        this.selectFOBTrade = page.getByText('LNG Global FOB Trades');

    }

    async LoginToE2E() {
        // await this.page.goto(getEnv().AuthoringToggleUrl);
        // await this.page.waitForTimeout(2000);
        // await this.page.getByTestId('toggle-off').nth(1).click();
        // await this.page.goto(getEnv().AuthoringToggleUrl);
        // await this.page.waitForTimeout(2000);
        // await this.page.getByTestId('toggle-off').nth(1).click();
        await this.page.goto(getEnv().AuthoringUrl);
    }

    async createNewPage() {
        await this.Click_CreateNew();
        const timestamp = new Date().getTime();
        //code to trim the timestamp to 3 digits
        const trimmedTimestamp = timestamp.toString().slice(-3);
        await this.headLine.fill("Automation-IntelPage-" + trimmedTimestamp);
        await this.pageDescription.fill("Automation-description");
        await this.nextbtn.click();
        await this.onecolumnTemplate.click();
        await this.createPageBtn.click();
        await this.page.waitForTimeout(2000);
        this.page_title = await this.pageTitle.textContent();
    }

    async add_Content() {
        //  await this.workflowstatuscontainer.click();
        await this.addContentBlock.click();
        await this.clickTableEntryCard.click();
        //  await this.workflowstatuscontainer.click();
    }

    async Click_CreateNew() {
        await this.createNew.click();
    }

    async clickConfiguration() {
        await this.configurationBtn.click();
    }

    async selectFOB() {
        await this.selectFOBTrade.click();
        await this.saveBtn.click();
    }

    async fillBuyer() {
        await this.buyer.first().click();
        await this.buyer_input.fill(TableData.data[0].Buyer);
        await this.buyer_input.press("Enter");
        await this.page.waitForTimeout(500);
    }

    async fillSeller() {
        await this.seller.first().click();
        await this.seller_input.fill(TableData.data[0].Seller);
        await this.seller_input.press("Enter");
        await this.page.waitForTimeout(500);
    }

    async fillTransactionDate() {
        await this.dateSelector.nth(0).waitFor();
        await this.dateSelector.nth(0).first().click();
        const selectTransactionDate = this.selectDate.getByText(TableData.data[0].TransactionDate, { exact: true });
        await selectTransactionDate.waitFor();
        await selectTransactionDate.click();
        await this.page.waitForTimeout(500);
    }

    async fillLiftingPeriodRange() {
        await this.dateSelector.nth(1).waitFor();
        await this.dateSelector.nth(1).first().click();
        await this.selectDate.getByText(TableData.data[0].LiftingPeriodFrom, { exact: true }).click();
        await this.selectDate.getByText(TableData.data[0].LiftingPeriodTo, { exact: true }).click();
        await this.page.waitForTimeout(500);
    }



    async fillPrice() {
        await this.price.first().click();
        await this.price_input.fill(TableData.data[0].Price);
        await this.page.waitForTimeout(500);
    }

    async fillVessel() {
        await this.vessel.first().click();
        await this.vessel_input.fill(TableData.data[0].Vessel);
        await this.vessel_input.press("Enter");
        await this.page.waitForTimeout(500);
    }


    async fillLoadPort() {
        await this.vessel.first().click();
        await this.vessel_input.fill(TableData.data[0].Vessel);
        await this.vessel_input.press("Enter");
        await this.page.waitForTimeout(500);
    }

    async clickPriceHeader() {
        await this.priceHeader.click();
    }
    async validateConfigurationvalues() {
        const DES = await this.selectDESTrade.textContent();
        const FOB = await this.selectFOBTrade.textContent();
        expect(DES).toEqual("LNG Global DES Trades");
        expect(FOB).toEqual("LNG Global FOB Trades");
    }

    async validateNotesIcon() {
        const notesIconVisibility = await this.notesIcon.first().isVisible();
        expect(notesIconVisibility).toBe(true);
    }

    async deleteNewPage() {
        await this.pricingIcon.click();
        await this.page.waitForTimeout(5000);
        await this.deleteIcon.first().click();
        await this.deleteButton.click();
        await this.page.waitForTimeout(1000);
        const firstPageTitle = await this.pageTitleLink.first().textContent();
        await this.page.waitForTimeout(3000);
        expect(firstPageTitle).not.toEqual(this.page_title);

    }

    async validateNewRowButton() {
        const newRowVisibility = await this.newRow.isVisible();
        expect(newRowVisibility).toBe(true);
    }

    async ValidatePublishBtn() {
        const publishBtnVisiility = await this.publishBtn.first().isEnabled();
        //console.log(publishBtnVisiility);
        expect(publishBtnVisiility).toBeTruthy();
    }

    async fillOrigin() {
        await this.origin.click();
        await this.origin_input.fill(TableData.data[0].Origin);
        await this.origin_input.press("Enter");
        await this.page.waitForTimeout(500);
    }

    async fillDestination() {
        await this.destination.click();
        await this.destination_input.fill(TableData.data[0].Destination);
        await this.destination_input.press("Enter");
        await this.page.waitForTimeout(500);
    }

    async fillDeliveryPeriodRange() {
        await this.dateSelector.nth(1).waitFor();
        await this.dateSelector.nth(1).click();
        await this.selectDate.getByText(TableData.data[0].DeliveryPeriodFrom, { exact: true }).click();
        await this.selectDate.getByText(TableData.data[0].DeliveryPeriodTo, { exact: true }).click();
    }

    async selectDES() {
        await this.selectDESTrade.click();
        await this.saveBtn.click();
    }

    async fillDataForFOB() {

        await this.fillBuyer();
        await this.fillSeller();
        await this.fillPrice();
        await this.fillVessel();
        await this.fillLoadPort();
        await this.fillTransactionDate();
        await this.fillLiftingPeriodRange();
        await this.clickPriceHeader();
    }

    async fillDataForDES() {
        await this.fillBuyer();
        await this.fillSeller();
        await this.fillPrice();
        await this.fillVessel();
        await this.fillOrigin();
        await this.fillDestination();
        await this.fillTransactionDate();
        await this.fillDeliveryPeriodRange();
        await this.clickPriceHeader();
    }

}

